package fr.uge.splendor;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Reservation {
	

	/**
	 * Let a player reserve a card from the tas from a wanted level
	 * @param gamer
	 * @param game
	 * @throws IOException
	 */
	public static void reservationPioche(Joueur gamer, Plateau game) throws IOException {
		int random;
		CarteDeveloppement carte;
		switch(ManipulationCarte.carteNiveau()) {
		case 1 ->{ if(game.cartes.get(1).size()==0) {
			return;}
			random = (int)(Math.random() * game.cartes.get(1).size());carte = game.cartes.get(1).get(random);
			gamer.reserve.add(carte);game.cartes.get(1).remove(random);}
		case 2 ->{if(game.cartes.get(2).size()==0) {
			return;}
			random = (int)(Math.random() * game.cartes.get(2).size());carte = game.cartes.get(2).get(random);
			gamer.reserve.add(carte);game.cartes.get(2).remove(random); }
		case 3->{if(game.cartes.get(3).size()==0) {
			return;}
			random = (int)(Math.random() * game.cartes.get(3).size());carte = game.cartes.get(3).get(random);
			gamer.reserve.add(carte);game.cartes.get(3).remove(random);}
		}
	}
	
	/**
	 * Let a player reserve a card on the board
	 * @param gamer
	 * @param game
	 * @throws IOException
	 */
	public static void reservationVisible(Joueur gamer, Plateau game) throws IOException {
		int selection;
		CarteDeveloppement carte;
		switch(ManipulationCarte.carteNiveau()) {
		case 1->{selection = ManipulationCarte.selectionCarteVisible();
			carte = game.carteVisible1.get(selection);gamer.reserve.add(carte);
			game.carteVisible1.remove(selection); 
			game.ajouteCarteVisible1();}
		case 2->{selection = ManipulationCarte.selectionCarteVisible();
			carte = game.carteVisible2.get(selection);gamer.reserve.add(carte);
			game.carteVisible2.remove(selection);
			game.ajouteCarteVisible2();}
		case 3->{selection = ManipulationCarte.selectionCarteVisible();
			carte = game.carteVisible3.get(selection);gamer.reserve.add(carte);
			game.carteVisible3.remove(selection);
			game.ajouteCarteVisible3();}
		}
	}
		
	/**
	 * If a player wants to reserve a card from a tas or from the cards on the board
	 * @return int
	 * @throws IOException
	 */
	public static int typeReservation() throws IOException {
		var line = new BufferedReader(new InputStreamReader(System.in));
		int action = 0;
		
		System.out.println("\n\nChoisissez une action :\n1 - Selection de la pile \n2 - selection carte visible\n");
		
		while(action != 1 && action != 2) {
			try {
				System.out.print(">> ");
				action = Integer.parseInt(line.readLine());
			} catch(NumberFormatException nfe) {
				System.err.println("Invalid Format");
			}
		}
		return action;
	}
	
	/**
	 * Auxiliary Method
	 * @param gamer
	 * @param game
	 * @throws IOException
	 */
	public static void reservationCarte(Joueur gamer, Plateau game) throws IOException {
		var choix = typeReservation();
		
		if(choix == 1) {
			reservationPioche(gamer, game);
		}
		else {
			reservationVisible(gamer, game);
		}
	}
	
	/*Verifie si il reste des pieces d'or sur le plateau
	 * si oui, le joueur pourra reccupere un jeton d'or l'or de la reserve d'une carte
	 * si non, le joueur pourra uniqueement reserver une carte sans avoir un bonus de piece d'or*/
	/**
	 * Check if there is still Golden tokens on the board
	 * if there is the player can take the golden token an reserve a card
	 * if not the player can only reserve a card
	 * @param gamer
	 * @param game
	 * @return boolean
	 * @throws IOException
	 */
	public static boolean reservationOr(Joueur gamer, Plateau game) throws IOException {
		if(gamer.reserve.size() < 3) {
			reservationCarte(gamer, game);
			
			if(Plateau.compteJeton("or") > 0) {
				//gamer.jeton_or++;
				gamer.jetons.compute("or", (k,v) -> v + 1);
				Plateau.jeton.compute("or", (k,v) -> v - 1);
			}
			return true;
		}
		return false;
	}
}
