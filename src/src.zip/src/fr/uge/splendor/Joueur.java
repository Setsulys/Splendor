package fr.uge.splendor;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class Joueur {
	public final int numero;
	public int prestige;
	public Map<String,Integer> jetons;
	public List<CarteDeveloppement> reserve;
	public List<CarteDeveloppement> cartepossede;
	public List<Nobles> noble;
	
	
	public Joueur(int numero, int prestige) {
		
		if(prestige < 0) {
			throw new IllegalStateException("prestige < 0");
		}
		this.numero = numero;
		this.prestige = prestige;
		
		jetons = new LinkedHashMap<String,Integer>();
		reserve = new ArrayList<CarteDeveloppement>();
		cartepossede = new ArrayList<CarteDeveloppement>();
		noble = new ArrayList<Nobles>();
	}
	public int numero() {
		return numero;
	}
	
	
	/**
	 * Iniitate the token of the player
	 */
	public  void initJetonJoueur() {
		jetons.computeIfAbsent("vert",k -> 0);
		jetons.computeIfAbsent("bleu",k -> 0);
		jetons.computeIfAbsent("rouge",k -> 0);
		jetons.computeIfAbsent("blanc",k -> 0);
		jetons.computeIfAbsent("noir",k -> 0);
		jetons.computeIfAbsent("or",k -> 0);
	}
	/**
	 * Calculate the white bonus number of the player
	 * @return int
	 */
	public int nbCarteBlanc() {
		int cartes_Blanc = 0;
		
		for(var element: cartepossede) {
			if(element.couleurBonus().equals("blanc")) {
				cartes_Blanc++;
			}
		}
		return cartes_Blanc;
	}
	

	/**
	 * Calculate the blue bonus number of the player
	 * @return int
	 */
	public int nbCarteBleu() {
		int cartes_Bleu = 0;
		
		for(var element: cartepossede) {
			if(element.couleurBonus().equals("bleu")) {
				cartes_Bleu++;
			}
		}
		return cartes_Bleu;
	}
	
	/**
	 * Calculate the green bonus number of the player
	 * @return int
	 */
	public int nbCarteVert() {
		int cartes_Vert = 0;
		
		for(var element: cartepossede) {
			if(element.couleurBonus().equals("vert")) {
				cartes_Vert++;
			}
		}
		return cartes_Vert;
	}
	
	/**
	 * Calculate the red bonus number of the player
	 * @return int
	 */
	public int nbCarteRouge() {
		int cartes_Rouge = 0;
		
		for(var element: cartepossede) {
			if(element.couleurBonus().equals("rouge")) {
				cartes_Rouge++;
			}
		}
		return cartes_Rouge;
	}

	/**
	 * Calculate the black bonus number of the player
	 * @return int
	 */
	public int nbCarteNoir() {
		int cartes_Noir = 0;
		
		for(var element: cartepossede) {
			if(element.couleurBonus().equals("noir")) {
				cartes_Noir++;
			}
		}
		return cartes_Noir;
	}
	
	/**
	 * Sum the number of white token counting bonus
	 * @return int
	 */
	public int jetonBlancTotal() {
		return nbCarteBlanc() + jetons.get("blanc") + jetons.get("or");
	}
	
	/**
	 * Sum the number of blue token counting bonus
	 * @return int
	 */
	public int jetonBleuTotal() {
		return nbCarteBleu() + jetons.get("bleu")+ jetons.get("or");
	}
	
	/**
	 * Sum the number of green token counting bonus
	 * @return int
	 */
	public int jetonVertTotal() {
		return nbCarteVert() +jetons.get("vert")+ jetons.get("or");
	}
	
	/**
	 * Sum the number of red token counting bonus
	 * @return int
	 */
	public int jetonRougeTotal() {
		return nbCarteRouge() + jetons.get("rouge")+ jetons.get("or");
	}
	
	/**
	 * Sum the number of black token counting bonus
	 * @return int
	 */
	public int jetonNoirTotal() {
		return nbCarteNoir() + jetons.get("noir")+ jetons.get("or");
	}
	
	/**
	 * Add the token to the player and withdraw it from the board 
	 * @param couleur
	 * @param gamer
	 */
	public void ajouteJeton(String couleur, Joueur gamer) {
		gamer.jetons.compute(couleur, (k,v) -> v + 1); Plateau.jeton.computeIfPresent(couleur, (k,v)-> v - 1);

	}
	
	@Override
	public String toString() {
		return "\n~~~~~~~~~~~~~~~~~ Joueur"+numero+" ~~~~~~~~~~~~~~~~~\nPrestige\t: " + prestige + 
				"  |  Jeton Or   \t: " + jetons.get("or") +"\n___________________________________________\n" +
				" \nJeton Vert\t: " + jetons.get("vert") + "  |  Carte verte\t: " + nbCarteVert() +
				" \nJeton Blanc\t: " + jetons.get("blanc") + "  |  Carte blanc\t: " + nbCarteBlanc() +
				" \nJeton Bleu\t: " + jetons.get("bleu") + "  |  Carte bleu\t: " + nbCarteBleu() +
				" \nJeton Noir\t: " + jetons.get("noir") + "  |  Carte noir\t: " + nbCarteNoir() +
				" \nJeton rouge\t: " + jetons.get("rouge") + "  |  Carte rouge\t: " + nbCarteRouge()+"\n";
	}
}
