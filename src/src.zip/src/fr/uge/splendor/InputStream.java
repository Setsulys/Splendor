package fr.uge.splendor;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class InputStream {

	/**
	 * Let the player select an action 
	 * - withdraw two tokens of the same colors
	 * - withdraw three tokens of differents colors
	 * - select a card to buy
	 * - select a card to reserve
	 * - select a card in the reserve to buy
	 * @return boolean
	 * @throws IOException
	 */
	public static int verifAction() throws IOException {
		var line = new BufferedReader(new InputStreamReader(System.in));
		int action = 0;
		
		System.out.println("\n\nChoisissez une action :\n1 - Pioche de jeton similaire \n2 - Pioche de jeton different\n3 - Selection de carte \n4 - Reservation de carte \n5 - Selection dans les cartes de reserve");
		while(action != 1 && action != 2 && action != 3 && action !=4 && action!=5) {
			try {
				System.out.print(">> ");
				action = Integer.parseInt(line.readLine());
			} catch(NumberFormatException nfe) {
				System.err.println("Invalid Format");
			}
		}
		return action;
	}

	/**
	 * Verify the color wanted from the stream
	 * @return String
	 * @throws IOException
	 */
	public static String choixCouleur() throws IOException { 
        var br = new BufferedReader(new InputStreamReader(System.in));
        String couleur = "";
        
        while (!couleur.equals("vert") && !couleur.equals("bleu") && !couleur.equals("rouge") && !couleur.equals("blanc") && !couleur.equals("noir")) {
        	try {
        		System.out.print("Choisisez une couleur >> ");
        		couleur = br.readLine();
        	} catch (NumberFormatException nfe) {
				System.err.println("Invalid Format");
        	}
        }
        return couleur;
    }
}
