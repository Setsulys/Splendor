package fr.uge.splendor;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Jeton {

	/**
	 * Add a number of token according to the number of player
	 * @param nb_joueur
	 */
	public static void ajouteJeton() {
		if(Plateau.nbjoueurs == 2) {
			Plateau.initJeton(4);
		}
		
		if(Plateau.nbjoueurs  == 3) {
			Plateau.initJeton(5);
		}
		
		if(Plateau.nbjoueurs  == 4) {
			Plateau.initJeton(7);
		}
	}
	
	/**
	 * Method that ask how many player there is to create the board properly
	 * @return int
	 * @throws IOException
	 */
	public static int nombreJoueur() throws IOException {
		var line = new BufferedReader(new InputStreamReader(System.in));
		int action = 0;
		
		System.out.println("\n\nChoisisez le nombre de joueurs :\n De 2 à 4 joueurs \n");
		
		while(action != 2 && action != 3 && action != 4) {
			try {
				System.out.print(">> ");
				action = Integer.parseInt(line.readLine());
			} catch(NumberFormatException nfe) {
				System.err.println("Invalid Format");
			}
		}
		return action;
	}
}
