package fr.uge.splendor;

import java.io.IOException;

public class PartieGraphique {
	
	/**
	 * WHen the player whant's to buy a level 1  card
	 * @param gamer
	 * @param game
	 * @param carte
	 * @return
	 */
	public static boolean achatNiveau1(Joueur gamer, Plateau game, int carte) {
		if(Partie.verifJetonJoueur(gamer, game, carte)) {
			Partie.retourJeton(gamer, game.carteVisible1.get(carte));
			gamer.cartepossede.add(game.carteVisible1.get(carte));
			game.carteVisible1.remove(carte);
			game.ajouteCarteVisible1();/*ajoute une carte de la pile sur le plateau si il en reste*/
			return true;
		}
		return false;
	}

	/**
	 * WHen the player whant's to buy a level 2  card
	 * @param gamer
	 * @param game
	 * @param carte
	 * @return
	 */
	public static boolean achatNiveau2(Joueur gamer, Plateau game, int carte) {
		if(Partie.verifJetonJoueur(gamer, game, carte)) {
			Partie.retourJeton(gamer, game.carteVisible2.get(carte));
			gamer.cartepossede.add(game.carteVisible2.get(carte));
			game.carteVisible2.remove(carte);
			game.ajouteCarteVisible2();/*ajoute une carte de la pile sur le plateau si il en reste*/
			return true;
		}
		return false;
	}
	
	/**
	 * WHen the player whant's to buy a level 3  card
	 * @param gamer
	 * @param game
	 * @param carte
	 * @return
	 */
	public static boolean achatNiveau3(Joueur gamer, Plateau game, int carte) {
		if(Partie.verifJetonJoueur(gamer, game, carte)) {
			Partie.retourJeton(gamer, game.carteVisible3.get(carte));
			gamer.cartepossede.add(game.carteVisible3.get(carte));
			game.carteVisible3.remove(carte);
			game.ajouteCarteVisible3();/*ajoute une carte de la pile sur le plateau si il en reste*/
			return true;
		}
		return false;
	}
	
	/**
	 * WHen the player whant's to reserve a level 1  card
	 * @param gamer
	 * @param game
	 * @param selection
	 * @return
	 */
	public static void reservationVisible1(Joueur gamer, Plateau game,int selection) {
		CarteDeveloppement carte;
		carte = game.carteVisible1.get(selection);
		gamer.reserve.add(carte);
		game.carteVisible1.remove(selection); 
		game.ajouteCarteVisible1();
	}
	
	/**
	 * WHen the player whant's to reserve a level 2  card
	 * @param gamer
	 * @param game
	 * @param selection
	 * @return
	 */
	public static void reservationVisible2(Joueur gamer, Plateau game,int selection) {
		CarteDeveloppement carte;
		carte = game.carteVisible2.get(selection);
		gamer.reserve.add(carte);
		game.carteVisible2.remove(selection); 
		game.ajouteCarteVisible2();
	}
	
	/**
	 * WHen the player whant's to reserve a level 3  card
	 * @param gamer
	 * @param game
	 * @param selection
	 * @return
	 */
	public static void reservationVisible3(Joueur gamer, Plateau game,int selection) {
		CarteDeveloppement carte;
		carte = game.carteVisible3.get(selection);
		gamer.reserve.add(carte);
		game.carteVisible3.remove(selection); 
		game.ajouteCarteVisible3();
	}
	
	/**
	 * When a player whant's to reserve in a Deck
	 * @param gamer
	 * @param game
	 * @throws IOException
	 */
	public static boolean reservationPioche(Joueur gamer, Plateau game, int selection) {
		int random;
		CarteDeveloppement carte;
		switch(selection - 4) {
		case 1->{if(game.cartes.get(1).size()==0) {
			return false;}
			random = (int)(Math.random() * game.cartes.get(1).size()); carte = game.cartes.get(1).get(random);
			gamer.reserve.add(carte); game.cartes.get(1).remove(random); return true;}
		case 2->{if(game.cartes.get(2).size()==0) {
			return false;}
			random = (int)(Math.random() * game.cartes.get(2).size()); carte = game.cartes.get(2).get(random);
			gamer.reserve.add(carte);game.cartes.get(2).remove(random);return true;}
		case 3 -> {if(game.cartes.get(3).size()==0) {
			return false;}
			random = (int)(Math.random() * game.cartes.get(3).size());carte = game.cartes.get(3).get(random);
			gamer.reserve.add(carte); game.cartes.get(3).remove(random);return true;}
		}
		return false;
	}
	
}
