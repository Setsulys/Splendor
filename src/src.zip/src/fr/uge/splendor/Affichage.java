package fr.uge.splendor;

public class Affichage {
	
	/**
	 * Display the tokens on the boards
	 */
	public static void afficherJetonPlateau() {
		System.out.println("jVert\t: " + Plateau.compteJeton("vert"));
		System.out.println("jBleu\t: " + Plateau.compteJeton("bleu"));
		System.out.println("jRouge\t: " + Plateau.compteJeton("rouge"));
		System.out.println("jBlanc\t: " + Plateau.compteJeton("blanc"));
		System.out.println("jNoir\t: " + Plateau.compteJeton("noir"));
		System.out.println("jOr  \t: " + Plateau.compteJeton("or"));
	}
	
	/**
	 * Display the cards on the board in visible state
	 * @param game
	 */
	public static void affichagePlateau(Plateau game) {
		System.out.println(game.noblesvisible.toString().replace("[","").replace(",","").replace("]","").replace(" ",""));/*A voir si on affiche*/
		System.out.println("Niveau 1\n" + game.carteVisible1.toString().replace("[","").replace(",","").replace("]","").replace(" ",""));
		System.out.println("Niveau 2\n" + game.carteVisible2.toString().replace("[","").replace(",","").replace("]","").replace(" ",""));
		System.out.println("Niveau 3\n" + game.carteVisible3.toString().replace("[","").replace(",","").replace("]","").replace(" ",""));
		afficherJetonPlateau();
	}

	
	/**
	 * Display all the player belonging
	 * @param gamer
	 */
	public static void affichageJoueur(Joueur gamer) {
		System.out.println(gamer.toString());
		System.out.println("Cartes reserve:\n"+ gamer.reserve.toString().replace(",","\n").replace("[", "").replace("]", "") );
		System.out.println("Nobles du joueur:\n" + gamer.noble.toString().replace(",","\n").replace("[", "").replace("]", "") );
		System.out.println("Cartes du joueur:\n" + gamer.cartepossede.toString().replace(",","\n").replace("[", "").replace("]", ""));
		System.out.println("________________________________________");
	}
}
