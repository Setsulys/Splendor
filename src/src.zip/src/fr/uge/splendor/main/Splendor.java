package fr.uge.splendor.main;

import java.io.IOException;
import java.nio.file.Path;

import fr.uge.splendor.*;

public class Splendor {

	/**
	 * Complete version of Splendor
	 * @throws IOException
	 */
	public static void splendor() throws IOException{
		var game = new Plateau();
		var partie = new Partie();
		var nbJoueur = new NbJoueurs();
		
		game.load(Path.of(/*"src","fr","uge","Splendor",*/"library","Splendor_Card_list.txt"));
		game.loadNobles(Path.of(/*"src","fr","uge","Splendor",*/"library","Splendor_Nobles.txt"));
		
		var joueurs = Jeton.nombreJoueur();
		
		
		
		System.out.println("Partie a "+ joueurs + " joueurs\n\n");
		
		if(joueurs == 2) {
			Plateau.nbjoueurs = 2;
			Jeton.ajouteJeton();
			nbJoueur.Partie2Joueur(game, partie);
		}
		
		else if(joueurs == 3) {
			Plateau.nbjoueurs = 3;
			Jeton.ajouteJeton();
			nbJoueur.Partie3Joueur(game, partie);
		}
		
		else {
			Plateau.nbjoueurs = 4;
			Jeton.ajouteJeton();
			nbJoueur.Partie4Joueur(game, partie);
		}
	}
}
