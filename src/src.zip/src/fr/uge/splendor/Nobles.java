package fr.uge.splendor;

import java.util.Objects;

public record Nobles(String name, int carte_blanc, int carte_bleu, int carte_vert, int carte_rouge, int carte_noir) {
	public Nobles(String name, int carte_blanc, int carte_bleu, int carte_vert, int carte_rouge, int carte_noir) {
		if(carte_blanc < 0 || carte_bleu < 0 || carte_vert < 0 || carte_rouge < 0 || carte_noir < 0) {
			throw new IllegalStateException("Nombre de carte invalide");
		}
		
		Objects.requireNonNull(name);
		
		this.name = name;
		this.carte_blanc = carte_blanc;
		this.carte_bleu = carte_bleu;
		this.carte_vert = carte_vert;
		this.carte_rouge = carte_rouge;
		this.carte_noir = carte_noir;
	}
	

	/**
	 * Add noble in the noble record from a file
	 * @param str
	 * @return Nobles
	 */
	public static Nobles fromText(String str) {
		var entry = str.split(" : ");
		return new Nobles(entry[0], Integer.parseInt(entry[1]), Integer.parseInt(entry[2]),Integer.parseInt(entry[3]), Integer.parseInt(entry[4]), Integer.parseInt(entry[5]));
	}
	
	/**
	 * Print the wanted string
	 */
	public String toString() {
		var builder = new StringBuilder();
		builder.append(name).append("\n");
		
		if(carte_blanc > 0) {
			builder.append("blanc :\t").append(carte_blanc).append("\t");
		}
		
		if(carte_bleu > 0) {
			builder.append("bleu :\t").append(carte_bleu).append("\t");
		}
		
		if(carte_vert > 0) {
			builder.append("vert :\t").append(carte_vert).append("\t");
		}
		
		if(carte_rouge > 0) {
			builder.append("rouge :\t").append(carte_rouge).append("\t");
		}
		
		if(carte_noir > 0) {
			builder.append("noir :\t").append(carte_noir).append("\t");
		}
		builder.append("\n");
		return builder.toString();
	}
}
