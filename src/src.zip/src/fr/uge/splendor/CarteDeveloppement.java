package fr.uge.splendor;

import java.util.Objects;

public record CarteDeveloppement (int niveau,int prestige, String couleurBonus, int jetonBlanc, int jetonBleu, int jetonVert, int jetonRouge, int jetonNoir){
	
	public CarteDeveloppement(int niveau,int prestige, String couleurBonus, int jetonBlanc, int jetonBleu, int jetonVert, int jetonRouge, int jetonNoir) {
		if((niveau!=1 && niveau!=2 && niveau!=3) ||prestige < 0 || jetonBlanc < 0 || jetonBleu < 0 || jetonVert < 0 || jetonRouge < 0 || jetonNoir < 0) {
			throw new IllegalArgumentException("Valeur invalide");
		}
		
		Objects.requireNonNull(couleurBonus);
		
		this.niveau=niveau;
		this.prestige = prestige;
		this.couleurBonus = couleurBonus;
		this.jetonBlanc = jetonBlanc;
		this.jetonBleu = jetonBleu;
		this.jetonVert = jetonVert;
		this.jetonRouge = jetonRouge;
		this.jetonNoir = jetonNoir;
	}
	/**
	 * Print the wanted string
	 */
	@Override
	public String toString() {
		var builder = new StringBuilder();
		builder.append(couleurBonus).append("\t Prestige:").append(prestige).append("\t");
		if(jetonBlanc > 0) {
			builder.append("blanc :\t").append(jetonBlanc).append("\t");
		}
		if(jetonBleu > 0) {
			builder.append("bleu :\t").append(jetonBleu).append("\t");
		}	
		if(jetonVert > 0) {
			builder.append("vert :\t").append(jetonVert).append("\t");
		}
		if(jetonRouge > 0) {
			builder.append("rouge :\t").append(jetonRouge).append("\t");
		}
		if(jetonNoir > 0) {
			builder.append("noir :\t").append(jetonNoir).append("\t");
		}	
		builder.append("\n");
		return builder.toString();
	}
	/**
	 * Check and put in the card in the good level from a file
	 * @param article
	 * @return CarteDeveloppement
	 */
	public static CarteDeveloppement fromText(String article) {
		var entry = article.split(" : ");
		
		switch(entry[0]) {
		case "niveau_1":
			return new CarteDeveloppement(1,Integer.parseInt(entry[1]), entry[2], Integer.parseInt(entry[3]), Integer.parseInt(entry[4]),Integer.parseInt(entry[5]), Integer.parseInt(entry[6]), Integer.parseInt(entry[7]));
		case "niveau_2":
			return new  CarteDeveloppement(2,Integer.parseInt(entry[1]), entry[2], Integer.parseInt(entry[3]), Integer.parseInt(entry[4]),Integer.parseInt(entry[5]), Integer.parseInt(entry[6]), Integer.parseInt(entry[7]));
		case "niveau_3":
			return new  CarteDeveloppement(3,Integer.parseInt(entry[1]), entry[2], Integer.parseInt(entry[3]), Integer.parseInt(entry[4]),Integer.parseInt(entry[5]), Integer.parseInt(entry[6]), Integer.parseInt(entry[7]));
		}
		return null;
	}
}
