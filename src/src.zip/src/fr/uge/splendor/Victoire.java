package fr.uge.splendor;

public class Victoire {
	
	/**
	 * sum the number of card of the player to see who will win
	 * @param gamer
	 * @return int
	 */
	public static int sommeCarte(Joueur gamer) {
		return gamer.nbCarteBlanc() + gamer.nbCarteBleu()+ gamer.nbCarteNoir() + gamer.nbCarteRouge() + gamer.nbCarteVert();
	}
	
	
	/**
	 * Overloading
	 * Check victory for two player
	 * @param gamer1
	 * @param gamer2
	 */
	public static void victoire(Joueur gamer1, Joueur gamer2) {
		var gamer3 = new Joueur(3,0);
		var gamer4 = new Joueur(4,0);
		victoire(gamer1,gamer2,gamer3,gamer4);
	}

	/**
	 * Overloading
	 * Check victory for two player
	 * @param gamer1
	 * @param gamer2
	 * @param gamer3
	 */
	public static void victoire(Joueur gamer1, Joueur gamer2, Joueur gamer3) {
		var gamer4 = new Joueur(4,0);
		victoire(gamer1,gamer2,gamer3,gamer4);
	}

	/**
	 * sum the number of player that have 15 of prestige
	 * @param gamer1
	 * @param gamer2
	 * @param gamer3
	 * @param gamer4
	 * @return int
	 */
	public static int compteNombrePrestige(Joueur gamer1, Joueur gamer2, Joueur gamer3, Joueur gamer4) {
		var somme=0;
		if( gamer1.prestige==15) {
			somme++;
		}
		if( gamer2.prestige==15) {
			somme++;
		}
		if( gamer3.prestige==15) {
			somme++;
		}
		if( gamer4.prestige==15) {
			somme++;
		}
		return somme;
	}
	
	/**
	 * Check the victory if there is a draw on the prestige
	 * check sum of developpement cards
	 * @param gamer1
	 * @param gamer2
	 * @return String
	 */
	public static String  victoireParSommeCarte2(Joueur gamer1, Joueur gamer2) {
		if(sommeCarte(gamer1)>sommeCarte(gamer2)) {
			return "Victoire du Joueur " + gamer1.numero() + "\n";
		}
		else if(sommeCarte(gamer2)>sommeCarte(gamer1)) {
			return "Victoire du Joueur " + gamer2.numero() + "\n";
		}
		else {
			return "Egalité entre les Joueurs "+ gamer1.numero() + " et " + gamer2.numero() + "\n" ;
		}
	}

	/**
	 * Check the victory if there is a draw on the prestige
	 * check sum of developpement cards
	 * @param gamer1
	 * @param gamer2
	 * @param gamer3
	 * @return String
	 */
	public static String victoireParSommeCarte3(Joueur gamer1, Joueur gamer2, Joueur gamer3) {
		if(sommeCarte(gamer1)>sommeCarte(gamer2)) {
			return victoireParSommeCarte2(gamer1,gamer3);
		}
		else if(sommeCarte(gamer2)>sommeCarte(gamer1)) {
			return victoireParSommeCarte2(gamer2,gamer3);
		}
		else {
			if(sommeCarte(gamer1)>sommeCarte(gamer3)) {
				return "Egalité entre les Joueurs " + gamer1.numero() +  " et " + gamer2.numero() + "\n";
			}
			else if(sommeCarte(gamer1)<sommeCarte(gamer3)) {
				return "Victoire du Joueur " + gamer3.numero();
			}
			else {
				return "Egalité entre les Joueurs " + gamer1.numero() + " , " + gamer2.numero() + " et " + gamer3.numero() + "\n";
			}
		}
	}
	

	/**
	 * Auxiliary method of victoireParSommeCarte4
	 * @param gamer
	 * @param gamer2
	 * @param gamer3
	 * @return String
	 */
	public static String victoireParSommeCarte4bis2(Joueur gamer, Joueur gamer2, Joueur gamer3) {
		if(sommeCarte(gamer) > sommeCarte(gamer3)) {
			return "Egalité entre les joueurs " + gamer.numero() + " et " + gamer2.numero() + "\n";
		}
		else if(sommeCarte(gamer) < sommeCarte(gamer3)) {
			return "victoire du Joueur " + gamer3.numero() + "\n";
		}
		else {
			return "Egalité entre les Joueurs " + gamer.numero() + " , " + gamer2.numero() + " et " + gamer3.numero() + "\n";
		}
	}
	
	/**
	 * Auxiliary method of victoireParSommeCarte4
	 * @param gamer
	 * @param gamer2
	 * @param gamer3
	 * @return String
	 */
	public static String victoireParSommeCarte4Prime(Joueur gamer, Joueur gamer2, Joueur gamer3) {
		if(sommeCarte(gamer) > sommeCarte(gamer2) ) {
			return victoireParSommeCarte2(gamer, gamer3);
		}
		else if(sommeCarte(gamer) < sommeCarte(gamer2)) {
			return victoireParSommeCarte2(gamer2, gamer3);
		}
		else {
			return victoireParSommeCarte4bis2(gamer,gamer2,gamer3);
		}
	}
	
	/**
	 * Auxiliary method of victoireParSommeCarte4
	 * @param gamer1
	 * @param gamer2
	 * @param gamer3
	 * @param gamer4
	 * @return String
	 */
	public static String victoireParSommeCarte4Second(Joueur gamer1, Joueur gamer2, Joueur gamer3, Joueur gamer4) {
		if(sommeCarte(gamer1) > sommeCarte(gamer3)) {
			return victoireParSommeCarte4bis2(gamer1,gamer2,gamer4);	
		}
		else if(sommeCarte(gamer1) < sommeCarte(gamer3)) {
			return victoireParSommeCarte2(gamer3, gamer4);
		}
		else {
			if(sommeCarte(gamer1) > sommeCarte(gamer4)) {
				return "Egalité entre les Joueurs " + gamer1.numero() +" , "+ gamer2.numero() + " et " + gamer3.numero() + "\n";
			}
			else if(sommeCarte(gamer1) < sommeCarte(gamer4)) {
				return "victoire du Joueur " + gamer4.numero() + "\n";
			}
			else {
				return "Egalité parfaite\n";
			}
		}
	}
	
	/**
	 * Check the victory if there is a draw on the prestige
	 * check sum of developpement cards
	 * @param gamer1
	 * @param gamer2
	 * @param gamer3
	 * @param gamer4
	 * @return String
	 */
	public static String victoireParSommeCarte4(Joueur gamer1, Joueur gamer2, Joueur gamer3, Joueur gamer4) {
		if(sommeCarte(gamer1) > sommeCarte(gamer2)) {
			return victoireParSommeCarte4Prime(gamer1,gamer3,gamer4);
		}
		else if(sommeCarte(gamer1) < sommeCarte(gamer2)) {
			return victoireParSommeCarte4Prime(gamer2,gamer3,gamer4);
		}
		else {
			return victoireParSommeCarte4Second(gamer1,gamer2,gamer3,gamer4);
		}
	}
	
	/*Verifie La victoire si il y a que un joueur ayant 15 de prestige*/
	/**
	 * Check the victory if there is a only a player at 15  of prestige
	 * @param gamer1
	 * @param gamer2
	 * @param gamer3
	 * @param gamer4
	 * @return String
	 */
	public static String joueurGagnant1(Joueur gamer1, Joueur gamer2, Joueur gamer3, Joueur gamer4) {
		if(gamer1.prestige == 15) {
			return "Victoire de\n" + gamer1.numero();
		}
		if(gamer2.prestige == 15) {
			return "Victoire de\n" + gamer2.numero();
		}
		if(gamer3.prestige == 15) {
			return "Victoire de\n" + gamer3.numero();
		}
		else {
			return "Victoire de\n" + gamer4.numero();
		}
	}
	
	/**
	 * Check the victory if there is two player at 15  of prestige
	 * @param gamer1
	 * @param gamer2
	 * @param gamer3
	 * @param gamer4
	 * @return String
	 */
	public static String joueurGagnant2(Joueur gamer1, Joueur gamer2, Joueur gamer3, Joueur gamer4) {
		if(gamer1.prestige==15 && gamer2.prestige==15) {
			return victoireParSommeCarte2( gamer1, gamer2);
		}
		else if(gamer1.prestige==15 && gamer3.prestige==15) {
			return victoireParSommeCarte2( gamer1, gamer3);
		}
		else if(gamer1.prestige==15 && gamer4.prestige==15) {
			return victoireParSommeCarte2( gamer1, gamer4);
		}
		else if(gamer2.prestige==15 && gamer3.prestige==15) {
			return victoireParSommeCarte2( gamer2, gamer3);
		}
		else if(gamer2.prestige==15 && gamer4.prestige==15) {
			return victoireParSommeCarte2( gamer2, gamer4);
		}
		else {
			return victoireParSommeCarte2( gamer3, gamer4);
		}
	}
	
	/**
	 * Check the victory if there is threeplayer at 15  of prestige	
	 * @param gamer1
	 * @param gamer2
	 * @param gamer3
	 * @param gamer4
	 * @return String
	 */
	public static String joueurGagnant3(Joueur gamer1, Joueur gamer2, Joueur gamer3, Joueur gamer4) {
		if(gamer1.prestige==15 && gamer2.prestige ==15 && gamer3.prestige==15) {
			return  victoireParSommeCarte3( gamer1, gamer2, gamer3);
		}
		else if(gamer1.prestige==15 && gamer2.prestige ==15 && gamer4.prestige==15) {
			return  victoireParSommeCarte3( gamer1, gamer2, gamer4);
		}
		else if(gamer1.prestige==15 && gamer4.prestige ==15 && gamer3.prestige==15) {
			return  victoireParSommeCarte3( gamer1, gamer4, gamer3);
		}
		else {
			return  victoireParSommeCarte3( gamer4, gamer2, gamer3);
		}
	}
	
	/**
	 * Check the victory if there is four player at 15  of prestige
	 * @param gamer1
	 * @param gamer2
	 * @param gamer3
	 * @param gamer4
	 * @return String
	 */
	public static String joueurGagnant4(Joueur gamer1, Joueur gamer2, Joueur gamer3, Joueur gamer4) {
		return victoireParSommeCarte4(gamer1, gamer2,gamer3,gamer4);
	}

	
	/**
	 * Check victory conditions
	 * @param gamer1
	 * @param gamer2
	 * @param gamer3
	 * @param gamer4
	 */
	public static void victoire(Joueur gamer1, Joueur gamer2, Joueur gamer3, Joueur gamer4) {
		 if (compteNombrePrestige(gamer1,gamer2,gamer3,gamer4)==1) {
			 System.out.println(joueurGagnant1(gamer1,gamer2,gamer3,gamer4)); 
		 }
		 else if(compteNombrePrestige(gamer1,gamer2,gamer3,gamer4)==2) {
			 System.out.println(joueurGagnant2(gamer1,gamer2,gamer3,gamer4)); 
		 }
		 else if(compteNombrePrestige(gamer1,gamer2,gamer3,gamer4)==3) {
			 System.out.println(joueurGagnant3(gamer1,gamer2,gamer3,gamer4)); 
		 }
		 else {
			 System.out.println(joueurGagnant4(gamer1,gamer2,gamer3,gamer4)); 
		 }
			 
	}
}
