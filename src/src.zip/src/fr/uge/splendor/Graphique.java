package fr.uge.splendor;

import fr.uge.splendor.*;
import java.awt.Color;
import java.awt.geom.*;
import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.awt.*;
import fr.umlv.zen5.Application;
import fr.umlv.zen5.ApplicationContext;
import fr.umlv.zen5.Event;
import fr.umlv.zen5.ScreenInfo;
import fr.umlv.zen5.Event.Action;
import fr.umlv.zen5.KeyboardKey;

public class Graphique {	 

	
	static class Cliker{
		ArrayList<Rectangle2D> buttons;

		
		public Cliker() {
			buttons = new ArrayList<Rectangle2D>();
		}
		
		/**
		 * Add the click zone of the tokens
		 * @param width
		 * @param height
		 */
		public void addToken(int width, int height) {
			buttons.add(new Rectangle2D.Double(width/25,height/10*3 + 50,(width/25),height/10-30));
			buttons.add(new Rectangle2D.Double(width/25,height/10*4 + 50,(width/25),height/10-30));
			buttons.add(new Rectangle2D.Double(width/25,height/10*5 + 50,(width/25),height/10-30));
			buttons.add(new Rectangle2D.Double(width/25,height/10*6 + 50,(width/25),height/10-30));
			buttons.add(new Rectangle2D.Double(width/25,height/10*7 + 50,(width/25),height/10-30));
		}
		
		/**
		 * Add the click zone of the Decks
		 * @param width
		 * @param height
		 */
		public void addDeck(int width, int height) {
			buttons.add(new Rectangle2D.Double(width/15 *2, height/12*2,width/15,height/10*2));
			buttons.add(new Rectangle2D.Double(width/15 *2, height/12*5,width/15,height/10*2));
			buttons.add(new Rectangle2D.Double(width/15 *2, height/12*8,width/15,height/10*2));
		}
		
		/**
		 * Add the click zone for every cards
		 * @param width
		 * @param height
		 */
		public void addCards(int width, int height) {
			var  largeur = width/10 +10;
			var hauteur = height/12;
			var hauteurbis = hauteur*4+20;
			var hauteurthird = hauteur*7+40;
			buttons.add(new Rectangle2D.Double(largeur*2,hauteur,width/10,hauteur*3));// Lv1 cards
			buttons.add(new Rectangle2D.Double(largeur*3,hauteur,width/10,hauteur*3));
			buttons.add(new Rectangle2D.Double(largeur*4,hauteur,width/10,hauteur*3));
			buttons.add(new Rectangle2D.Double(largeur*5,hauteur,width/10,hauteur*3));
			buttons.add(new Rectangle2D.Double(largeur*2,hauteurbis,width/10,hauteur*3));//Lv2 cards
			buttons.add(new Rectangle2D.Double(largeur*3,hauteurbis,width/10,hauteur*3));
			buttons.add(new Rectangle2D.Double(largeur*4,hauteurbis,width/10,hauteur*3));
			buttons.add(new Rectangle2D.Double(largeur*5,hauteurbis,width/10,hauteur*3));
			buttons.add(new Rectangle2D.Double(largeur*2,hauteurthird,width/10,hauteur*3));//Lv3 cards
			buttons.add(new Rectangle2D.Double(largeur*3,hauteurthird,width/10,hauteur*3));
			buttons.add(new Rectangle2D.Double(largeur*4,hauteurthird,width/10,hauteur*3));
			buttons.add(new Rectangle2D.Double(largeur*5,hauteurthird,width/10,hauteur*3));
		}
		
		/**
		 * Add the click zone for reserved cards
		 * @param width
		 * @param height
		 */
		public void addReserve(int width, int height) {
			buttons.add(new Rectangle2D.Double(width/5*4+20,height/20*13,width/5-40,height/15));
			buttons.add(new Rectangle2D.Double(width/5*4+20,height/20*15,width/5-40,height/15));
			buttons.add(new Rectangle2D.Double(width/5*4+20,height/20*17,width/5-40,height/15));
		}
		
		/**
		 * Add all the click zone
		 * @param width
		 * @param height
		 */
		public void addbuttons(int width, int height) {
			addToken(width,height);
			addDeck(width,height);
			addCards(width,height);
			addReserve(width,height);
		}
		
		/**
		 * Check if the user have clicked on the right zone
		 * @param event
		 * @return
		 */
		public int checkClic(Event event) {
			if(event.getAction()==Action.POINTER_DOWN) {
				if(event != null) {
					var i =0;
					for(var element : this.buttons) {
						if(element.contains(event.getLocation())) {
							return i;
						}
						i++;
					}
				}
			}
			return -1;
		}
		
		/**
		 * Check when a player wants to take a token
		 * @param event
		 * @return
		 */
		public String prendJeton(Event event) {
			switch(checkClic(event)) {
			case 0 -> {return "vert";}
			case 1 -> {return "blanc";}
			case 2 -> {return "rouge";}
			case 3 -> {return "bleu";}
			case 4 -> {return "noir";}
			default ->{return " ";}
			}
		}
		
		/**
		 * Check when a player want's to take a card
		 * @param clic
		 * @param gamer
		 * @param game
		 * @return
		 */
		public boolean prendCarte(int clic, Joueur gamer, Plateau game) {
			switch(clic) {
			case 8 -> {return PartieGraphique.achatNiveau1(gamer, game, 0);}
			case 9 -> {return PartieGraphique.achatNiveau1(gamer, game, 1);}
			case 10-> {return PartieGraphique.achatNiveau1(gamer, game, 2);}
			case 11 ->{return PartieGraphique.achatNiveau1(gamer, game, 3);}
			case 12 -> {return PartieGraphique.achatNiveau2(gamer, game, 0);}
			case 13 -> {return PartieGraphique.achatNiveau2(gamer, game, 1);}
			case 14 -> {return PartieGraphique.achatNiveau2(gamer, game, 2);}
			case 15 -> {return PartieGraphique.achatNiveau2(gamer, game, 3);}
			case 16 -> {return PartieGraphique.achatNiveau3(gamer, game, 0);}
			case 17 -> {return PartieGraphique.achatNiveau3(gamer, game, 1);}
			case 18 -> {return PartieGraphique.achatNiveau3(gamer, game, 2);}
			case 19 -> {return PartieGraphique.achatNiveau3(gamer, game, 3);}
			}
			return false;
		}
		
		/**
		 * check when a player whant's to buy a Reserved Card
		 * @param clic
		 * @param gamer
		 * @param game
		 * @return
		 */
		public boolean prendReserve(int clic,Joueur gamer, Plateau game) {
			return Partie.achatReserve(gamer, clic - 20);
		}
		
		/**
		 * Check when a player whants to reserve a card 
		 * @param clic
		 * @param gamer
		 * @param game
		 * @return
		 */
		public boolean reserveCarte(int clic, Joueur gamer, Plateau game) {
			if(gamer.reserve.size()>=3) {
				return false;
			}
			switch(clic) {
			case 8 -> {PartieGraphique.reservationVisible1(gamer, game, 0);}
			case 9 -> { PartieGraphique.reservationVisible1(gamer, game, 1);}
			case 10-> { PartieGraphique.reservationVisible1(gamer, game, 2);}
			case 11 ->{ PartieGraphique.reservationVisible1(gamer, game, 3);}
			case 12 -> { PartieGraphique.reservationVisible2(gamer, game, 0);}
			case 13 -> { PartieGraphique.reservationVisible2(gamer, game, 1);}
			case 14 -> { PartieGraphique.reservationVisible2(gamer, game, 2);}
			case 15 -> { PartieGraphique.reservationVisible2(gamer, game, 3);}
			case 16 -> { PartieGraphique.reservationVisible3(gamer, game, 0);}
			case 17 -> { PartieGraphique.reservationVisible3(gamer, game, 1);}
			case 18 -> { PartieGraphique.reservationVisible3(gamer, game, 2);}
			case 19 -> { PartieGraphique.reservationVisible3(gamer, game, 3);}
			}
			return true;
		}
		
		/**
		 *Check When a player whant's to reserve a card in the deck
		 * @param clic
		 * @param gamer
		 * @param game
		 * @return
		 */
		public boolean reserveCartePioche(int clic, Joueur gamer,Plateau game) {
			return PartieGraphique.reservationPioche(gamer, game, clic);
		}
		
		
		/**
		 * Exit of the program
		 * @param context
		 * @param key
		 */
		public void exit(ApplicationContext context,KeyboardKey key) {
        	if(key == KeyboardKey.Q) {
		          context.exit(0);
		          return;
	        	}
		}
		
		/**
		 * Main loop of graphic
		 * @param context
		 * @param event
		 */
		public void loop( ApplicationContext context, Event event) {
			 Action action = event.getAction();
	        KeyboardKey key = event.getKey();
	        if ((action== Action.KEY_PRESSED || action == Action.KEY_RELEASED) ) {
	        	if(key==KeyboardKey.R) {
	        		for(var i = 0; i <= 1;i++) {
		        		event = context.pollOrWaitEvent(10000);
		        		 if (event == null) {  // no event
		       	          continue;
		        		 }
		        		System.out.println(checkClic(event) + "R");
	        		}
	        	}
	        	exit(context,key);
	        }
	        else {
	        	System.out.println(checkClic(event));
	        }
		}
		
	}
	
	static class Draw{
		private final static Color darkblue = new Color(0,0,20);
		private final static Color yellow = new Color(230,130,0);
		private final static Color yellowdark = new Color(120,70,0);
		
		
		/**
		 * Display a background of color(0,0,20) for the board
		 * @param context
		 * @param width
		 * @param height
		 */
		void drawBackground(ApplicationContext context, int width, int height){
		      context.renderFrame(graphics -> {
    	        graphics.setColor(darkblue);
    	        graphics.fill(new Rectangle2D.Double(0,0,width,height));
		      });
		}
		
		/**
		 * Display Level one Cards on the board permitting player to draw these cards when he want
		 * @param context
		 * @param width
		 * @param height
		 */
		void drawLv1(ApplicationContext context, int width, int height) {
			var  largeur = width/10 +10;
			var hauteur = height/12;
			context.renderFrame(graphics ->{
				graphics.setColor(Color.GRAY);
				graphics.fill(new Rectangle2D.Double(largeur*2,hauteur,width/10,hauteur*3));
				graphics.fill(new Rectangle2D.Double(largeur*3,hauteur,width/10,hauteur*3));
				graphics.fill(new Rectangle2D.Double(largeur*4,hauteur,width/10,hauteur*3));
				graphics.fill( new Rectangle2D.Double(largeur*5,hauteur,width/10,hauteur*3));
			});
		}
		
		/**
		 * Display Level two Cards on the board permitting player to draw these cards when he want
		 * @param context
		 * @param width
		 * @param height
		 */
		void drawLv2(ApplicationContext context, int width, int height) {
			var largeur = width/10+10;
			var hauteur = height/12;
			var hauteurbis = hauteur*4+20;
			context.renderFrame(graphics ->{
				graphics.setColor(Color.GRAY);
				graphics.fill(new Rectangle2D.Double(largeur*2,hauteurbis,width/10,hauteur*3));
				graphics.fill(new Rectangle2D.Double(largeur*3,hauteurbis,width/10,hauteur*3));
				graphics.fill(new Rectangle2D.Double(largeur*4,hauteurbis,width/10,hauteur*3));
				graphics.fill(new Rectangle2D.Double(largeur*5,hauteurbis,width/10,hauteur*3));
			});
		}
		
		/**
		 * Display Level three Cards on the board permitting player to draw these cards when he want
		 * @param context
		 * @param width
		 * @param height
		 */
		void drawLv3(ApplicationContext context, int width, int height) {
			var largeur = width/10+10;
			var hauteur = height/12;
			var hauteurbis = hauteur*7+40;
			context.renderFrame(graphics ->{
				graphics.setColor(Color.GRAY);
				graphics.fill(new Rectangle2D.Double(largeur*2,hauteurbis,width/10,hauteur*3));
				graphics.fill(new Rectangle2D.Double(largeur*3,hauteurbis,width/10,hauteur*3));
				graphics.fill(new Rectangle2D.Double(largeur*4,hauteurbis,width/10,hauteur*3));
				graphics.fill(new Rectangle2D.Double(largeur*5,hauteurbis,width/10,hauteur*3));
			});
		}
		
		/**
		 * Display Noble cards on the board 
		 * @param context
		 * @param width
		 * @param height
		 */
		void drawNoble(ApplicationContext context, int width, int height) {
			var largeur = width*13/20+10;
			var hauteur = height/6+10;
			var hauteurbis = height/6;
			context.renderFrame(graphics ->{
				graphics.setColor(Color.GRAY);
				graphics.fill(new Rectangle2D.Double(largeur,hauteur*0+10,width/8,hauteurbis));
				graphics.fill(new Rectangle2D.Double(largeur,hauteur+20,width/8,hauteurbis));
				graphics.fill(new Rectangle2D.Double(largeur,hauteur*2+30,width/8,hauteurbis));
				graphics.fill(new Rectangle2D.Double(largeur,hauteur*3+40,width/8,hauteurbis));
				graphics.fill(new Rectangle2D.Double(largeur,hauteur*4+50,width/8,hauteurbis));
			});
		}
		
		/**
		 * Display all three level of deck permitting players to draw a card from it when 
		 * want to save a card
		 * @param context
		 * @param width
		 * @param height
		 */
		void drawDeck(ApplicationContext context, int width, int height) {
			context.renderFrame(graphics ->{
				graphics.setColor(Color.GRAY);
				graphics.fill(new Rectangle2D.Double(width/15 *2, height/12*2,width/15,height/10*2));
				graphics.fill(new Rectangle2D.Double(width/15 *2, height/12*5,width/15,height/10*2));
				graphics.fill(new Rectangle2D.Double(width/15 *2, height/12*8,width/15,height/10*2));
			});
		}

		
		/**
		 * Draw the place where the tokens are displayed
		 * @param context
		 * @param width
		 * @param height
		 */
		void drawTokenPlace(ApplicationContext context, int width, int height){
			context.renderFrame(graphics -> {
				graphics.setColor(yellow);
				graphics.fill(new Rectangle2D.Double(width/100,(height/20)*2,width/10,height/20*17-40));
    	        graphics.setColor(yellowdark);
    	        graphics.fill(new Rectangle2D.Double(width/25,height/10*3 + 50,(width/25),height/10-30));
    	        graphics.fill(new Rectangle2D.Double(width/25,height/10*4 + 50,(width/25),height/10-30));
    	        graphics.fill(new Rectangle2D.Double(width/25,height/10*5 + 50,(width/25),height/10-30));
    	        graphics.fill(new Rectangle2D.Double(width/25,height/10*6 + 50,(width/25),height/10-30));
    	        graphics.fill(new Rectangle2D.Double(width/25,height/10*7 + 50,(width/25),height/10-30));
				
			});
		}
		
		/**
		 * Display Player interface background
		 * @param context
		 * @param width
		 * @param height
		 */
		void drawPlayerStatus(ApplicationContext context, int width, int height) {
		      context.renderFrame(graphics -> {
    	        graphics.setColor(yellow);
    	        graphics.fill(new Rectangle2D.Double(width/5*4,0,width,height));
    	        graphics.setColor(yellowdark);
    	        graphics.fill(new Rectangle2D.Double(width/5*4+20,20,width/5-40,height/2));
		      });
		}
		
		/**
		 * Display Buttons permitting player to buy a card from it reserve
		 * @param context
		 * @param width
		 * @param height
		 */
		void drawPlayerReserveButton(ApplicationContext context, int width, int height) {
			context.renderFrame(graphics -> {
    	        graphics.setColor(yellowdark);
    	        graphics.fill(new Rectangle2D.Double(width/5*4+20,height/20*13,width/5-40,height/15));
    	        graphics.fill(new Rectangle2D.Double(width/5*4+20,height/20*15,width/5-40,height/15));
    	        graphics.fill(new Rectangle2D.Double(width/5*4+20,height/20*17,width/5-40,height/15));
		      });
		}
		
		
		
		/**
		 * Draw tokens, Cards that are on the board
		 * @param context
		 * @param width
		 * @param height
		 */
		void drawBoard(ApplicationContext context, int width, int height) {
			drawTokenPlace(context, width, height);
			drawDeck(context, width, height);
			drawLv1(context, width, height);
			drawLv2(context, width, height);
			drawLv3(context, width, height);
			drawNoble(context, width, height);
		}
		
		/**
		 * Draw Player Status block
		 * @param context
		 * @param width
		 * @param height
		 */
		void drawPlayerDisplay(ApplicationContext context, int width, int height) {
			drawPlayerStatus(context, width, height);
			drawPlayerReserveButton(context, width, height);
		}
		
		/**
		 * Draw the name of the deck
		 * @param context
		 * @param width
		 * @param height
		 */
		void drawDeckName(ApplicationContext context, int width, int height,int heightp, String niveau) {
			context.renderFrame(graphics ->{
				graphics.setFont(new Font("New TimeRoman", Font.BOLD,height/15));
				graphics.setColor(yellow);
				graphics.drawString("Lv",width/100*15,height/100*28+heightp);
				graphics.drawString(niveau,width/100*16,height/100*35+heightp);
			});
		}
		
		/**
		 * Draw all Method used above
		 * @param context
		 * @param width
		 * @param height
		 */
		void drawAll(ApplicationContext context, int width, int height) {
			var t = height/100*26;
			drawBackground(context, width, height);
			drawBoard(context, width, height);
			drawPlayerDisplay(context, width, height);
			drawDeckName(context, width, height,0,"1");
			drawDeckName(context, width, height,t,"2");
			drawDeckName(context, width, height,t*2,"3");
		}
		
	}

	static class Values{
		
		private final static Color green = new Color(58,209,98);
		private final static Color red = new Color(231,60,62);
		private final static Color blue = new Color(60,60,250);
		/**
		 * Display the remaining tokens on the board
		 * @param context
		 * @param width
		 * @param height
		 */
		void tokens(ApplicationContext context, int width, int height){
			context.renderFrame(graphics -> {
				graphics.setFont(new Font("New TimeRoman", Font.BOLD,height/15));
				graphics.setColor(Color.YELLOW);
				graphics.drawString("[" + Plateau.jeton.get("or") + "]",(width/30),height/10*2);
				graphics.setColor(green);
				graphics.drawString("[" +Plateau.jeton.get("vert") + "]",(width/30),height/10*4);
				graphics.setColor(Color.WHITE);
				graphics.drawString("[" +Plateau.jeton.get("blanc") + "]",(width/30),height/10*5);
				graphics.setColor(red);
				graphics.drawString("[" +Plateau.jeton.get("rouge") + "]",(width/30),height/10*6);
				graphics.setColor(blue);	
				graphics.drawString("[" +Plateau.jeton.get("bleu") + "]",(width/30),height/10*7);
				graphics.setColor(Color.BLACK);
				graphics.drawString("[" +Plateau.jeton.get("noir") + "]",(width/30),height/10*8);
		       
			});
		}

		
		/**
		 * Display player tokens and bonuses
		 * the yellow token represent gold token
		 * @param context
		 * @param width
		 * @param height
		 */
		void playerTokens(ApplicationContext context, int width, int height, Joueur gamer) {
			context.renderFrame(graphics -> {
				graphics.setFont(new Font("New TimeRoman", Font.BOLD,height/15));
				graphics.drawString("Joueur " + gamer.numero ,(width/50*42),height/10);
				graphics.setColor(Color.YELLOW);
				graphics.drawString("0/15",(width/50*44),height/10*2);
				graphics.drawString(gamer.jetons.get("or").toString(),(width/50*43),height/10*3);
				graphics.setColor(green);
				graphics.drawString(gamer.jetons.get("vert") + "[" + gamer.nbCarteVert() + "]",(width/50*42),height/10*4);
				graphics.setColor(Color.WHITE);
				graphics.drawString(gamer.jetons.get("blanc") + "[" + gamer.nbCarteBlanc() + "]",(width/50*42),height/10*5);
				graphics.setColor(red);
				graphics.drawString(gamer.jetons.get("rouge") + "[" + gamer.nbCarteRouge() + "]",(width/50*46),height/10*3);
				graphics.setColor(blue);
				graphics.drawString(gamer.jetons.get("bleu") + "[" + gamer.nbCarteBleu() + "]",(width/50*46),height/10*4);
				graphics.setColor(Color.BLACK);
				graphics.drawString(gamer.jetons.get("noir") + "[" + gamer.nbCarteNoir() + "]",(width/50*46),height/10*5);
			});
		}
		
		/**
		 * Show Player saved cards and the values of token needed to buy it
		 * @param context
		 * @param width
		 * @param height
		 * @param font
		 */
		void playerReserveColor(ApplicationContext context, int width, int height, int font, CarteDeveloppement card) {
			context.renderFrame(graphics -> {
				graphics.setFont(new Font("New TimeRoman", Font.BOLD,font/18));
				graphics.setColor(red);
				graphics.drawString(card.jetonRouge()+"" ,width*88,height);
				graphics.setColor(green);
				graphics.drawString(card.jetonVert()+"",width*90,height);
				graphics.setColor(blue);
				graphics.drawString(card.jetonBleu()+"",width*92,height);
				graphics.setColor(Color.WHITE);
				graphics.drawString(card.jetonBlanc()+"",width*94,height);
				graphics.setColor(Color.BLACK);
				graphics.drawString(card.jetonNoir()+"",width*96,height);
				
			});
		}
		
		Color couleurBonus(CarteDeveloppement card) {
			switch(card.couleurBonus()) {
			case "rouge" -> {return red;}
			case "vert" -> {return green;}
			case "bleu" -> {return blue;}
			case "blanc" -> {return Color.WHITE;}
			case "noir" ->{ return Color.BLACK;}
			default -> {return Color.GRAY;}
			}
		}
		/**
		 * Show the bonus that the player will aquire when he buy a card that he saved before
		 * The color of the token change with the color of the bonus
		 * @param context
		 * @param width
		 * @param height
		 * @param font
		 */
		void playerReserveBonus(ApplicationContext context, int width, int height, int font, CarteDeveloppement card) {
			context.renderFrame(graphics -> {
				graphics.setFont(new Font("New TimeRoman", Font.BOLD,font/18));
				graphics.setColor(couleurBonus(card));
				graphics.drawString(card.prestige()+"",width*84,height);
			});
		}
		
		/**
		 * Auxiliary Method that display all reserve cards and it bonuses
		 * @param context
		 * @param width
		 * @param height
		 */
		void playerReserve(ApplicationContext context, int width, int height, Joueur gamer) {
			context.renderFrame(graphics -> {
				graphics.setFont(new Font("New TimeRoman", Font.BOLD,height/20));
				graphics.drawString("Reserve",(width/50*43),height/10*6);
				if(gamer.reserve.size()>=1) {
					playerReserveBonus(context, width/100,height/10*7,height,gamer.reserve.get(1));
					playerReserveColor(context,(width/100),height/10*7,height,gamer.reserve.get(1));
				}
				if(gamer.reserve.size()>=2) {
					playerReserveBonus(context, width/100,height/10*8,height,gamer.reserve.get(2));
					playerReserveColor(context,(width/100),height/10*8,height,gamer.reserve.get(2));
				}
				if(gamer.reserve.size()>=3) {
					playerReserveBonus(context, width/100,height/10*9,height,gamer.reserve.get(3));
					playerReserveColor(context,(width/100),height/10*9,height,gamer.reserve.get(3));
				}
			});
		}
		
		/**
		 * Display the values needed by one Noble card
		 * @param context
		 * @param width
		 * @param height
		 * @param heightp
		 */
		
		void noblesValues(ApplicationContext context, int width, int height, int heightp, Nobles no) {
			context.renderFrame(graphics ->{
				graphics.setFont(new Font("New TimeRoman",Font.BOLD,height/15));
				graphics.drawString("[3]",(width/100)*67,(height/100)*7+heightp);
				graphics.setColor(green);
				graphics.drawString(no.carte_vert()+"",(width/100)*72,(height/100)*7+heightp);
				graphics.setColor(blue);
				graphics.drawString(no.carte_bleu()+"",(width/100)*76,(height/100)*7+heightp);
				graphics.setColor(Color.BLACK);
				graphics.drawString(no.carte_noir()+"",(width/100)*68,(height/100)*16+heightp);
				graphics.setColor(Color.WHITE);
				graphics.drawString(no.carte_blanc()+"",(width/100)*72,(height/100)*16+heightp);
				graphics.setColor(red);
				graphics.drawString(no.carte_rouge()+"",(width/100)*76,(height/100)*16+heightp);
			});
		}
		
		
		/**
		 * Display all the Nobles cards values
		 * @param context
		 * @param width
		 * @param height
		 */
		void allNoblesValue(ApplicationContext context, int width, int height, Plateau game) {
			var taille = height/100*21;
			if(game.noblesvisible.size()>=1) {
				noblesValues(context, width, height,0,game.noblesvisible.get(0));
			}
			if(game.noblesvisible.size()>=2) {
				noblesValues(context, width, height,taille,game.noblesvisible.get(1));
			}
			if(game.noblesvisible.size()>=3) {
				noblesValues(context, width, height,taille*2,game.noblesvisible.get(2));
			}
			if(game.noblesvisible.size()>=4) {
				noblesValues(context, width, height,taille*3,game.noblesvisible.get(3));
			}
			if(game.noblesvisible.size()>=5) {
				noblesValues(context, width, height,taille*4,game.noblesvisible.get(4));
			}	
		}
		
		
		/**
		 * Display Developpement card values
		 * @param context
		 * @param width
		 * @param height
		 * @param placew
		 * @param placeh
		 * @param card
		 */
		void cardValues(ApplicationContext context, int width, int height,int placew,int placeh,CarteDeveloppement card){
			context.renderFrame(graphics -> {
				graphics.setFont(new Font("New TimeRoman", Font.BOLD,height/15));
				graphics.setColor(couleurBonus(card));
				graphics.drawString("[" + card.prestige() + "]",((width/100)*22)+placew,height/100*17+placeh);
				graphics.setColor(Color.WHITE);
				graphics.drawString(card.jetonBlanc()+"",(width/100)*23+placew,height/100*33+placeh);
				graphics.setColor(blue);
				graphics.drawString(card.jetonBleu()+"",(width/100)*23+placew,height/100*25+placeh);
				graphics.setColor(green);
				graphics.drawString(card.jetonVert()+"",(width/100)*28+placew,height/100*17+placeh);
				graphics.setColor(red);
				graphics.drawString(card.jetonRouge()+"",(width/100)*28+placew,height/100*33+placeh);
				graphics.setColor(Color.BLACK);
				graphics.drawString(card.jetonNoir()+"",(width/100)*28+placew,height/100*25+placeh);
			});
		}
		
		/**
		 * Display all Developpement cards values
		 * @param context
		 * @param width
		 * @param height
		 * @param game
		 */
		void displayAllCardsValues(ApplicationContext context, int width, int height, Plateau game) {
			var line = height/100*30;
			var column  = width/100*11;
			cardValues(context, width, height,0,0, game.carteVisible1.get(0));/*Column 1*/
			cardValues(context, width, height,0,line,game.carteVisible2.get(0));
			cardValues(context, width, height,0,line*2,game.carteVisible3.get(0));
			
			cardValues(context, width, height,column,0,game.carteVisible1.get(1));/*Column 2*/
			cardValues(context, width, height,column,line,game.carteVisible2.get(1));
			cardValues(context, width, height,column,line*2,game.carteVisible3.get(1));
			
			cardValues(context, width, height,column*2,0,game.carteVisible1.get(2));/*Column 3*/
			cardValues(context, width, height,column*2,line,game.carteVisible2.get(2));
			cardValues(context, width, height,column*2,line*2,game.carteVisible3.get(2));
			
			cardValues(context, width, height,column*3,0,game.carteVisible1.get(3));/*Column 4*/
			cardValues(context, width, height,column*3,line,game.carteVisible2.get(3));
			cardValues(context, width, height,column*3,line*2,game.carteVisible3.get(3));
		}
		
		

		/**
		 * Show All the values of the player
		 * @param context
		 * @param width
		 * @param height
		 * @throws IOException 
		 */
		void DisplayValues(ApplicationContext context, int width, int height) throws IOException {
			var game = new Plateau();
			Plateau.nbjoueurs = 4;
			Jeton.ajouteJeton();
			Joueur gamer = new Joueur(1,0);
			game.load(Path.of(/*"src","fr","uge","Splendor",*/"library","Splendor_Card_list.txt"));
			game.loadNobles(Path.of(/*"src","fr","uge","Splendor",*/"library","Splendor_Nobles.txt"));
			gamer.initJetonJoueur();
			game.afficheNoble();
			game.ajoute_carte_visible();
			tokens(context, width, height);
			displayAllCardsValues(context, width, height,game);
			allNoblesValue(context, width, height,game);
			playerTokens(context, width, height,gamer);
			playerReserve(context, width, height, gamer);
			
		}
	}
	
	
	static class Display{
		
		
		/**
		 * Display all the board
		 * @param context
		 * @param width
		 * @param height
		 * @throws IOException 
		 */
		void display(ApplicationContext context, int width, int height) throws IOException {
			Draw dis = new Draw();
			Values val = new Values();
			dis.drawAll(context, width, height);
			val.DisplayValues(context, width, height);
		}
	}
	
	static void playing(ApplicationContext context, int width, int height, Cliker clic) {
		for(;;) {	
	        Event event = context.pollOrWaitEvent(10);
	        if (event == null) {  // no event
	          continue;
	        }
	       clic.loop(context, event);
		}
	}
	
	  public static void graphics() {
		  Display d = new Display();
		  Cliker cl = new Cliker();
	    Application.run(Color.BLACK, context -> {
	      ScreenInfo screenInfo = context.getScreenInfo();
	      float width = screenInfo.getWidth();
	      float height = screenInfo.getHeight();
	      System.out.println("size of the screen (" + width + " x " + height + ")");
	      try {
			d.display(context,  Math.round(width),Math.round(height));
		} catch (IOException e) {
		}
	      cl.addbuttons(Math.round(width),Math.round(height));
	      playing(context,  Math.round(width),Math.round(height),cl);
	      
	    });
	  }
}
