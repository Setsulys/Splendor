package fr.uge.splendor;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ManipulationCarte {
	

	/**
	 * Manipulate the card selection to know the card wanted
	 * @return int
	 * @throws IOException
	 */
	public static int selectionCarteVisible() throws IOException {
		var line = new BufferedReader(new InputStreamReader(System.in));
		int action = 0;
		
		System.out.println("\n\n Selection carte 1-2-3-4\n");
		
		while(action != 1 && action != 2 && action != 3 && action != 4) {
			try {
				System.out.print(">> ");
				action = Integer.parseInt(line.readLine());
			} catch(NumberFormatException nfe) {
				System.err.println("Invalid Format");
			}
		}
		return action - 1;
	}
	
	/**
	 * Maniulate the card selection to know the reserved card wanted
	 * @return int
	 * @throws IOException
	 */
	public static int selectionCarteReserve() throws IOException {
		var line = new BufferedReader(new InputStreamReader(System.in));
		int action = 0;
		
		System.out.println("\n\n Selection carte 1-2-3\n");
		
		while(action != 1 && action != 2 && action != 3) {
			try {
				System.out.print(">> ");
				action = Integer.parseInt(line.readLine());
			} catch(NumberFormatException nfe) {
				System.err.println("Invalid Format");
			}
		}
		return action - 1;
	}

	/**
	 * Check the level selection wanted
	 * @return int
	 * @throws IOException
	 */
	public static int carteNiveau() throws IOException {
		var line = new BufferedReader(new InputStreamReader(System.in));
		int action = 0;
		
		System.out.println("\n\nChoisissez une action :\n1 - selection carte niveau 1 \n2 - selection carte niveau 2 \n3 - selection carte niveau 3 \n");
		
		while(action != 1 && action != 2 && action != 3) {
			try {
				System.out.print(">> ");
				action = Integer.parseInt(line.readLine());
			} catch(NumberFormatException nfe) {
				System.err.println("Invalid Format");
			}
		}
		return action;
	}
}
