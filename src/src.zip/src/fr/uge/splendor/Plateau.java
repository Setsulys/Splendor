package fr.uge.splendor;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class Plateau {
	
	public final HashMap<Integer, ArrayList<CarteDeveloppement>> cartes;
	
	public  List<CarteDeveloppement> carteVisible1;
	public  List<CarteDeveloppement> carteVisible2;
	public  List<CarteDeveloppement> carteVisible3;
	
	private final List<Nobles> nobles;
	public List<Nobles> noblesvisible;
	
	
	public static Map<String,Integer> jeton;
	
	public static int nbjoueurs;
	
	public Plateau() {
		cartes = new LinkedHashMap<Integer,ArrayList<CarteDeveloppement>>();
		
		carteVisible1 = new ArrayList<CarteDeveloppement>();
		carteVisible2 = new ArrayList<CarteDeveloppement>();
		carteVisible3 = new ArrayList<CarteDeveloppement>();
		
		nobles = new ArrayList<Nobles>();
		noblesvisible = new ArrayList<Nobles>();
		jeton = new LinkedHashMap<String,Integer>();
	}
	
	/**
	 * Add Developpement card on their proper level at the start of the game
	 * @param carte
	 */
	public void add(int niveau,CarteDeveloppement carte) {
		ArrayList<CarteDeveloppement> cartesD; 
		Objects.requireNonNull(carte);
		cartesD = cartes.get(niveau);
		if(cartesD == null) {
			cartesD = new ArrayList<CarteDeveloppement>();
			cartesD.add(carte);
			cartes.put(niveau, cartesD);
		}
		else {
			if(! cartesD.contains(carte)) {
				cartesD.add(carte);
			}
		}
	}

	
	/**
	 * Add card of level 1 in a visible state, if there is less than 4 and there is in the tas 
	 */
	public void ajouteCarteVisible1() { 
		do {
			var randomized = (int)(Math.random() * cartes.get(1).size());
			CarteDeveloppement carte1 = cartes.get(1).get(randomized);
			carteVisible1.add(carte1);
			cartes.get(1).remove(randomized);
		} while (carteVisible1.size() < 4 && cartes.get(1).size() > 0);
	}
	
	/**
	 * Add card of level 2 in a visible state, if there is less than 4 and there is in the tas 
	 */
	public void ajouteCarteVisible2() { 
		do {
			var randomized = (int)(Math.random() * cartes.get(2).size());
			CarteDeveloppement carte2 = cartes.get(2).get(randomized);
			carteVisible2.add(carte2);
			cartes.get(2).remove(randomized);
		} while (carteVisible2.size() < 4 && cartes.get(2).size() > 0);
	}
	
	/**
	 * Add card of level 3 in a visible state, if there is less than 4 and there is in the tas 
	 */
	public void ajouteCarteVisible3() { 
		do {
			var randomized = (int)(Math.random() * cartes.get(3).size());
			CarteDeveloppement carte3 = cartes.get(3).get(randomized);
			carteVisible3.add(carte3);
			cartes.get(3).remove(randomized);
		} while (carteVisible3.size() < 4 && cartes.get(3).size() > 0);
	}
	
	/**
	 * Add all type of card in a visible state (used in the preparation of the game)
	 */
	public void ajoute_carte_visible() {
		ajouteCarteVisible1();
		ajouteCarteVisible2();
		ajouteCarteVisible3();
	}
	
	/**
	 * Add nobles cards in the tas
	 * @param noble
	 */
	public void addNoble(Nobles noble) {
		Objects.requireNonNull(noble);
		nobles.add(noble);
	}
	
	/**
	 * Randomly select number of player +1 of nobles card form the tas to put it on the board
	 * There will not be a withdrawal in the game progress
	 */
	public void afficheNoble() {
		do {
			var randomized = (int)(Math.random() * nobles.size());
			Nobles carte = nobles.get(randomized);
			noblesvisible.add(carte);
			nobles.remove(randomized);
		} while ((noblesvisible.size() < nbjoueurs + 1) && nobles.size() > 0);
	}
	
	
	/**
	 * Init Token in the game
	 * @param nbJeton
	 */
	public static void initJeton(int nbJeton) {
		jeton.computeIfAbsent("vert",k -> nbJeton);
		jeton.computeIfAbsent("bleu",k -> nbJeton);
		jeton.computeIfAbsent("rouge",k -> nbJeton);
		jeton.computeIfAbsent("blanc",k -> nbJeton);
		jeton.computeIfAbsent("noir",k -> nbJeton);
		jeton.computeIfAbsent("or",k -> 5);
	}
	
	/**
	 * Check how many type of token are still on the board to avoid a softlock if there is less than 3 types of token
	 * @return int
	 */
	public static int resteJeton() {
		var reste = 0;
		for(var element : jeton.entrySet()) {
			if(element.getValue() > 0) {
				reste++;
			}
		}
		return reste;
	}
	
	/**
	 * Check if there is still the type of token asked
	 * @param couleur
	 * @return boolean
	 */
	public boolean verifJeton(String couleur) {
		if (jeton.get(couleur) > 0) {	
			return true;
		}	
		return false;
	}
	/**
	 * Check if there is sill 4 token of the same type when a player wants to take two similar tokens
	 * @param couleur
	 * @return boolean
	 */
	public boolean verifJetonSimilaire(String couleur) {
		if(jeton.get(couleur) >= 4) {
			return true;
		}
		return false;
	}
	
	public static int compteJeton(String couleur){
		return jeton.get(couleur);
	}
	
	/**
	 * Load from a file , the developpement card needed for the game
	 * @param path
	 * @param cs
	 * @throws IOException
	 */
	public void load(Path path, Charset cs) throws IOException {
		try (var reader = Files.newBufferedReader(path, cs)) { 
			String ligne;
			
			while ((ligne = reader.readLine()) != null) {
				CarteDeveloppement newcards = CarteDeveloppement.fromText(ligne);
				this.add(newcards.niveau(),newcards);
			}
		}
	}

	/**
	 * Overloading 
	 * Load from a file , the developpement card needed for the game with a charset UTF8
	 * @param path
	 * @throws IOException
	 */
	public void load(Path path) throws IOException {
		load(path, Charset.forName("UTF-8"));
	}

	/**
	 * Load nobles card from a file 
	 * @param path
	 * @param cs
	 * @throws IOException
	 */
	public void loadNobles(Path path, Charset cs) throws IOException {
		try (var reader = Files.newBufferedReader(path, cs)) {
			String ligne;
			
			while ((ligne = reader.readLine()) != null) {
				this.addNoble(Nobles.fromText(ligne));
			}
		}
	}

	/**
	 * Overloading
	 * Load nobles card from a file 
	 * @param path
	 * @throws IOException
	 */
	public void loadNobles(Path path) throws IOException {
		loadNobles(path, Charset.forName("UTF-8"));
	}
}
