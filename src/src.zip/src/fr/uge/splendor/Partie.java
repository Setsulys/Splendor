package fr.uge.splendor;
import java.io.IOException;

public class Partie {
	

	/**
	 * The player have a visit from a noble if there is still noble on the board
	 * @param gamer
	 * @param game
	 */
	public void visiteDeNoble(Joueur gamer, Plateau game) {
		var iterator = game.noblesvisible.iterator();
		
		while(iterator.hasNext()) {
			var value = iterator.next();
			
			if(gamer.nbCarteBlanc() == value.carte_blanc() && gamer.nbCarteBleu() == value.carte_bleu() && gamer.nbCarteVert() == value.carte_vert() && gamer.nbCarteRouge() == value.carte_rouge() && gamer.nbCarteNoir() == value.carte_noir()) {
				System.out.println("~~~~~~~~~~~VISITE D'UN NOBLE~~~~~~~~~~~\n~~~~~~~~~~~"+ value.name() + "~~~~~~~~~~~\n");
				iterator.remove();
				gamer.prestige += 3;
				gamer.noble.add(value);
			}	
		}
	}
	
	/**
	 * Return true if the player have enough token to buy the card
	 * @param gamer
	 * @param game
	 * @param carte_choisis
	 * @return boolean
	 */
	public static boolean verifJetonJoueur(Joueur gamer, Plateau game,int carte_choisis) {
		var carte = game.carteVisible1.get(carte_choisis);
		
		if((gamer.jetonBlancTotal() > carte.jetonBlanc()) && (gamer.jetonBleuTotal() > carte.jetonBleu()) && (gamer.jetonVertTotal() > carte.jetonVert()) && (gamer.jetonRougeTotal() > carte.jetonRouge()) && (gamer.jetonNoirTotal() > carte.jetonNoir())) {
			return true;
		}
		return false;
	}
	
	/**
	 * When a player buy a card, the tokens needed are replaced on the board minus the bonus number that he already have
	 * @param gamer
	 * @param carte
	 */
	public static void retourJeton(Joueur gamer,CarteDeveloppement carte) {		
		Plateau.jeton.compute("blanc", (k,v) -> v + (carte.jetonBlanc() - gamer.nbCarteBlanc()));
		Plateau.jeton.compute("bleu", (k,v) -> v + (carte.jetonBleu() - gamer.nbCarteBleu()));
		Plateau.jeton.compute("vert", (k,v) -> v + (carte.jetonVert() - gamer.nbCarteVert()));
		Plateau.jeton.compute("rouge", (k,v) -> v + (carte.jetonRouge() - gamer.nbCarteRouge()));
		Plateau.jeton.compute("noir", (k,v) -> v + (carte.jetonNoir() - gamer.nbCarteNoir()));
	}
	

	/**
	 * When a player wants to buy a level 1 card
	 * there is a token check
	 * if there is enough token, the player will buy and the tokens will be replaced
	 * if a card is taken a new card is put on the board 
	 * @param gamer
	 * @param game
	 * @return
	 * @throws IOException
	 */
	public static boolean achatNiveau1(Joueur gamer, Plateau game) throws IOException {
		var carte = ManipulationCarte.selectionCarteVisible();
		
		if(verifJetonJoueur(gamer, game, carte)) {
			retourJeton(gamer, game.carteVisible1.get(carte));
			gamer.cartepossede.add(game.carteVisible1.get(carte));
			game.carteVisible1.remove(carte);
			game.ajouteCarteVisible1();/*ajoute une carte de la pile sur le plateau si il en reste*/
			return true;
		}
		return false;
	}
	
	/**
	 * When a player wants to buy a level 2 card
	 * there is a token check
	 * if there is enough token, the player will buy and the tokens will be replaced
	 * if a card is taken a new card is put on the board 
	 * @param gamer
	 * @param game
	 * @return boolean
	 * @throws IOException
	 */
	public static boolean achatNiveau2(Joueur gamer, Plateau game) throws IOException {
		var carte = ManipulationCarte.selectionCarteVisible()+1;
		
		if(verifJetonJoueur(gamer, game, carte)) {
			retourJeton(gamer, game.carteVisible2.get(carte));
			gamer.cartepossede.add(game.carteVisible2.get(carte));
			game.carteVisible2.remove(carte);
			game.ajouteCarteVisible2();/*ajoute une carte de la pile sur le plateau si il en reste*/
			return true;
		}
		return false;
	}
	
	/**
	 * When a player wants to buy a level 3 card
	 * there is a token check
	 * if there is enough token, the player will buy and the tokens will be replaced
	 * if a card is taken a new card is put on the board 
	 * @param gamer
	 * @param game
	 * @return boolean
	 * @throws IOException
	 */
	public static boolean achatNiveau3(Joueur gamer, Plateau game) throws IOException {
		var carte = ManipulationCarte.selectionCarteVisible()+1;
	
		if(verifJetonJoueur(gamer, game, carte)) {
			retourJeton(gamer, game.carteVisible3.get(carte));
			gamer.cartepossede.add(game.carteVisible3.get(carte));
			game.carteVisible3.remove(carte);
			game.ajouteCarteVisible3();/*ajoute une carte de la pile sur le plateau si il en reste*/
			return true;
		}
		return false;
	}
	
	/**
	 * Ask to the player what level the player wants to buy
	 * @param gamer
	 * @param game
	 * @return boolean
	 * @throws IOException
	 */
	public static boolean joueurAcheteCarte(Joueur gamer, Plateau game) throws IOException {
		switch(ManipulationCarte.carteNiveau()) {
		case 1: 
			return achatNiveau1(gamer, game);
		case 2: 
			return achatNiveau2(gamer, game);
		case 3: 
			return achatNiveau3(gamer, game);
		}
		return false;
	}
	
	/**
	 * Let the player buy his reserved card
	 * @param gamer
	 * @param carte_choisis
	 * @return boolean
	 */
	public static boolean achatReserve(Joueur gamer, int carte_choisis) {
		if(gamer.reserve.size()==0) {
			System.out.println("pas de carte dans la reserve \n");
			return false;
		}
		if(carte_choisis > gamer.reserve.size()) {
			return false;
		}
		
		var carte = gamer.reserve.get(carte_choisis);
		
		if((gamer.jetonBlancTotal() > carte.jetonBlanc()) && (gamer.jetonBleuTotal() > carte.jetonBleu()) && (gamer.jetonVertTotal() > carte.jetonVert()) && (gamer.jetonRougeTotal() > carte.jetonRouge()) && (gamer.jetonNoirTotal() > carte.jetonNoir())) {
			retourJeton(gamer, gamer.reserve.get(carte_choisis));
			gamer.cartepossede.add(carte);
			gamer.reserve.remove(carte);
			return true;
		}
		return false;
	}
	

	
	/**
	 * When the player decide to take three different tokens 
	 * if there is less than 3 types of token the player will take only two different token
	 * the same if ther is only one token
	 * @param gamer
	 * @param game
	 * @return boolean
	 * @throws IOException
	 */
	public boolean joueurPiocheJeton(Joueur gamer,Plateau game) throws IOException {
		if(Plateau.resteJeton() >= 3) {
			return joueurPiocheJetonDifferent(InputStream.choixCouleur(), InputStream.choixCouleur(), InputStream.choixCouleur(), gamer, game);
		}
		
		if(Plateau.resteJeton() == 2) {
			return joueurPiocheJetonDifferentDeuxCouleur(InputStream.choixCouleur(), InputStream.choixCouleur(), gamer, game);
		}
		
		if(Plateau.resteJeton() == 1) {
			return joueurPiocheJetonDifferentUneCouleur(InputStream.choixCouleur(), gamer, game); 
		}
		return false;
	}
	
	/**
	 * If there is only one type of token the player will take this one
	 * @param couleur1
	 * @param gamer
	 * @param game
	 * @return boolean
	 */
	public boolean joueurPiocheJetonDifferentUneCouleur(String couleur1, Joueur gamer, Plateau game) {
		if (game.verifJeton(couleur1)) {
			gamer.ajouteJeton(couleur1, gamer);
			return true;
		}
		return false;
	}

	/**
	 * If there is only two type of token the player will take one of each
	 * @param couleur1
	 * @param couleur2
	 * @param gamer
	 * @param game
	 * @return boolean
	 */
	public boolean joueurPiocheJetonDifferentDeuxCouleur(String couleur1, String couleur2, Joueur gamer, Plateau game) {
		if ((!couleur1.equals(couleur2) && !couleur1.equals(couleur2))) {
			if (game.verifJeton(couleur1) && game.verifJeton(couleur2)) {
				gamer.ajouteJeton(couleur1, gamer);
				gamer.ajouteJeton(couleur2, gamer);
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Let a player take 3 token of different colors
	 * @param couleur1
	 * @param couleur2
	 * @param couleur3
	 * @param gamer
	 * @param game
	 * @return boolean
	 */
	public boolean joueurPiocheJetonDifferent(String couleur1, String couleur2, String couleur3, Joueur gamer, Plateau game) {
		if ((!couleur1.equals(couleur2) && !couleur1.equals(couleur3) && !couleur2.equals(couleur3))) {
			if (game.verifJeton(couleur1) && game.verifJeton(couleur2) && game.verifJeton(couleur3)) {
				gamer.ajouteJeton(couleur1, gamer);
				gamer.ajouteJeton(couleur2, gamer);
				gamer.ajouteJeton(couleur3, gamer);
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Check if the player wants to take two token of the same color
	 * @param couleur
	 * @param gamer
	 * @param game
	 * @return boolean
	 */
	public boolean joueurPiocheJetonSimilaire(String couleur, Joueur gamer, Plateau game) {
		int nb_jeton = 2;
		
		if (game.verifJetonSimilaire(couleur)) {
			while (nb_jeton > 0 && game.verifJeton(couleur)) {
				gamer.ajouteJeton(couleur, gamer);
				nb_jeton--;
			}
			return true;
		}
		return false;
	}
	

	
	/**
	 * Auxiliary Method
	 * @param gamer
	 * @param game
	 * @throws IOException
	 */
	public void choixAction(Joueur gamer, Plateau game) throws IOException {
		var action = InputStream.verifAction();
		switch(action) {
		case 1: 
			if (!(joueurPiocheJetonSimilaire(InputStream.choixCouleur(), gamer, game))) {  /* Prendre 3 jetons pierre precieuse de couleur differente. */
				choixAction(gamer, game);
			} break;
		case 2: 
			if (!(joueurPiocheJeton(gamer, game))) { /* Prendre 2 jetons pierre precieuse de la meme couleur. (token == 4) */
				choixAction(gamer, game);
			} break; 
		case 3: 
			if (!joueurAcheteCarte(gamer, game)) { // Acheter 1 carte developpement face visible au centre de la table
				choixAction(gamer, game);
			} break;
		case 4: 
			if(!Reservation.reservationOr(gamer, game)) { //reserve une carte de developpement et donne un jeton d'or si il en reste
				choixAction(gamer,game);
			} break;
		case 5: 
			if(!achatReserve(gamer,ManipulationCarte.selectionCarteReserve())) {//le joueur achete une carte qu'il a réservé
				choixAction(gamer,game);
			} break;
		}
	}
}
