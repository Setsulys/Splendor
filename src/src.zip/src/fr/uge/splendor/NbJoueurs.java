package fr.uge.splendor;

import java.io.IOException;

public class NbJoueurs {
	
	/**
	 * Display all the thing needed for a wanted player
	 * @param gamer
	 * @param game
	 * @param partie
	 * @throws IOException
	 */
	public void TourJoueur(Joueur gamer,Plateau game, Partie partie) throws IOException {
		Affichage.affichagePlateau(game);
		Affichage.affichageJoueur(gamer);
		partie.choixAction(gamer,game);
		partie.visiteDeNoble(gamer,game);
		Affichage.affichageJoueur(gamer);
		System.out.println("\n");
	}
	
	/**
	 * Create a game with two player
	 * @param game
	 * @param partie
	 * @throws IOException
	 */
	public void Partie2Joueur(Plateau game, Partie partie) throws IOException {
		var gamer = new Joueur(1, 0);
		var gamer2 = new Joueur(2, 0);
		gamer.initJetonJoueur();
		gamer2.initJetonJoueur();
		
		game.afficheNoble();
		game.ajoute_carte_visible();
		while(gamer.prestige < 15 && gamer2.prestige <15) {
			
			TourJoueur(gamer,game,partie);
			TourJoueur(gamer2,game,partie);
		}
		Victoire.victoire(gamer, gamer2);
	}
	
	/**
	 * Create a game with three player
	 * @param game
	 * @param partie
	 * @throws IOException
	 */
	public void Partie3Joueur(Plateau game,Partie partie) throws IOException {
		var gamer = new Joueur(1, 0);
		var gamer2 = new Joueur(2, 0);
		var gamer3 = new Joueur(3, 0);
		gamer.initJetonJoueur();
		gamer2.initJetonJoueur();
		gamer3.initJetonJoueur();
		
		game.afficheNoble();
		game.ajoute_carte_visible();
		while(gamer.prestige < 15 && gamer2.prestige <15 && gamer3.prestige <15) {
			
			TourJoueur(gamer,game,partie);
			TourJoueur(gamer2,game,partie);
			TourJoueur(gamer3,game,partie);
		}
		Victoire.victoire(gamer, gamer2, gamer3);
	}
	
	/**
	 * Create a game with four player
	 * @param game
	 * @param partie
	 * @throws IOException
	 */
	public void Partie4Joueur(Plateau game,Partie partie) throws IOException {
		var gamer = new Joueur(1, 0);
		var gamer2 = new Joueur(2, 0);
		var gamer3 = new Joueur(3, 0);
		var gamer4 = new Joueur(4, 0);
		gamer.initJetonJoueur();
		gamer2.initJetonJoueur();
		gamer3.initJetonJoueur();
		gamer4.initJetonJoueur();
		game.afficheNoble();
		game.ajoute_carte_visible();
		while(gamer.prestige < 15 && gamer2.prestige <15 && gamer3.prestige <15 && gamer4.prestige <15) {
			TourJoueur(gamer,game,partie);
			TourJoueur(gamer2,game,partie);
			TourJoueur(gamer3,game,partie);
			TourJoueur(gamer4,game,partie);
		}
		Victoire.victoire(gamer, gamer2, gamer3, gamer4);
	}
}
