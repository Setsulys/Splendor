package fr.uge.simpleversion.main;

import java.io.IOException;
import java.nio.file.Path;

import fr.uge.simpleversion.Joueur;
import fr.uge.simpleversion.Partie;
import fr.uge.simpleversion.Plateau;

public class SplendorSimple {
	
	/**
	 * Simple version of the game with two player a all developpment card have one of prestige
	 * @throws IOException
	 */
	public static void splendorSimple() throws IOException {
		var game = new Plateau();
		var partie = new Partie();
		
		var player1 = new Joueur(1,0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
		var player2 = new Joueur(2,0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
		
		game.load(Path.of(/*"src","fr","uge","simpleversion",*/"library","Splendor_simplified_Card_list.txt"));
		
		partie.partieDeJeu(player1, player2, game);
	}
}
