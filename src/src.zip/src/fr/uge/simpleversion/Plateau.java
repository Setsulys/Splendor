package fr.uge.simpleversion;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Plateau {
	public final List<CarteDev> pile_carte;
	public final List<CarteDev> carte_visible;
	public static int jeton_vert = 4;
	public static int jeton_bleu = 4;
	public static int jeton_rouge = 4;
	public static int jeton_blanc = 4;
	public static int jeton_noir = 4;
	
	/**
	 * Board Constructor, We use pre-condition to check the tokens values
	 */
	public Plateau() {
		if(jeton_vert < 0 || jeton_vert > 4) {
			throw new IllegalStateException("jeton_vert < 0 || jeton_vert > 4");
		}
		if(jeton_bleu < 0 || jeton_bleu > 4) {
			throw new IllegalStateException("jeton_bleu < 0 || jeton_bleu > 4");
		}
		if(jeton_rouge < 0 || jeton_rouge > 4) {
			throw new IllegalStateException("jeton_rouge < 0 || jeton_rouge > 4");
		}
		if(jeton_blanc < 0 || jeton_blanc > 4) {
			throw new IllegalStateException("jeton_blanc < 0 || jeton_blanc > 4");
		}
		if(jeton_noir < 0 || jeton_noir > 4) {
			throw new IllegalStateException("jeton_noir < 0 || jeton_noir > 4");
		}
		
		pile_carte = new ArrayList<CarteDev>();
		carte_visible = new ArrayList<CarteDev>();
	}
	
	/**
	 * Tas initialisation
	 * @param carte
	 */
	public void adding(CarteDev carte) {
		Objects.requireNonNull(carte);
		pile_carte.add(carte);
	}

	/**
	 * Withdraw and retire card randomly from the tas and place it in a visible state 
	 */
	public void afficheCarteVisible() { 
		do {
			var randomized = (int)(Math.random() * pile_carte.size());
			CarteDev carte = pile_carte.get(randomized);
			carte_visible.add(carte);
			pile_carte.remove(randomized);
		} while (carte_visible.size() < 4 && pile_carte.size() > 0);
	}
	
	
	/**
	 * We look if the player enter the good colors and if it is right, this card will be withdraw from the board
	 * @param couleur
	 * @return CarteDev
	 */
	public CarteDev carteAchat(String couleur) {
		if (!(couleur.equals("vert")) && !(couleur.equals("bleu")) && !(couleur.equals("rouge")) && !(couleur.equals("blanc")) && !(couleur.equals("noir"))) {
			return null;
		}
		
		for (var element : carte_visible) {
			if (element.couleur().equals(couleur)) {
				carte_visible.remove(element);
				return element;
			}
		}
		return null;
	}
	
	/**
	 * Count how many type of token there is on the board
	 * @return int
	 */
	public static int resteJeton() {
		int reste = 0;
		
		if(jeton_vert > 0) {
			reste++;
		}
		if(jeton_bleu > 0) {
			reste++;
		}
		if(jeton_rouge > 0) {
			reste++;
		}
		if(jeton_blanc > 0) {
			reste++;
		}
		if(jeton_noir > 0) {
			reste++;
		}
		return reste;
	}
	
	/**
	 * If there is at least one token of the type this method return true
	 * @param couleur
	 * @return boolean
	 */
	public boolean verifJeton(String couleur) {
		if (couleur.equals("vert") && jeton_vert > 0) {
			return true;
		}
		if (couleur.equals("bleu") && jeton_bleu > 0) {
			return true;
		}
		if (couleur.equals("rouge") && jeton_rouge > 0) {
			return true;
		}
		if (couleur.equals("blanc") && jeton_blanc > 0) {
			return true;
		}
		if (couleur.equals("noir") && jeton_noir > 0) {
			return true;
		}
		return false;
	}
	
	/**
	 * We look if there is at least 4 token of the same color on the board
	 * @param couleur
	 * @return boolean
	 */
	public boolean verifJetonSimilaire(String couleur) {
		if (couleur.equals("vert") && jeton_vert >= 4) {
			return true;
		}
		if (couleur.equals("bleu") && jeton_bleu >= 4) {
			return true;
		}
		if (couleur.equals("rouge") && jeton_rouge >= 4) {
			return true;
		}
		if (couleur.equals("blanc") && jeton_blanc >= 4) {
			return true;
		}
		if (couleur.equals("noir") && jeton_noir >= 4) {
			return true;
		}
		return false;
	}

	/**
	 * Display tokens that are on the board
	 */
	public void afficherJetonPlateau() {
		System.out.println("Vert\t: " + jeton_vert);
		System.out.println("Bleu\t: " + jeton_bleu);
		System.out.println("Rouge\t: " + jeton_rouge);
		System.out.println("Blanc\t: " + jeton_blanc);
		System.out.println("Noir\t: " + jeton_noir);
	}
	
	/**
	 * Sum the cards that the player have bought 
	 * @param gamer
	 * @return int
	 */
	public int sommeCarte(Joueur gamer) {
		return gamer.nb_carte_vert + gamer.nb_carte_bleu + gamer.nb_carte_rouge + gamer.nb_carte_blanc + gamer.nb_carte_noir;
	}
	
	/* On compare le nombre de prestige entre les 2 joueurs, si cette valeur est identique on compare aussi le nombre de carte de ces joueurs, 
	et on renvoie donc une valeur en fonction de ces informations */
	
	/**
	 * Comparing the prestige value between the two player, if this value is the same, the method
	 * also compare the number of card that the player have bought and return 1 if the gamer1  won
	 * 2 if the gamer2 won and 0 if it's a draw 
	 * @param gamer1
	 * @param gamer2
	 * @return int
	 */
	public int victoire(Joueur gamer1, Joueur gamer2) {
		if (gamer1.prestige > gamer2.prestige) {
			return 1;
		}
		else if (gamer1.prestige == gamer2.prestige) {
			if (sommeCarte(gamer1) > sommeCarte(gamer2)) {
				return 1;
			}
			else if (sommeCarte(gamer1) == sommeCarte(gamer2)) {
				return 0;
			}
		}
		return 2;
	}
	
	/**
	 * Display at the end of the game who have win the game
	 * @param gamer1
	 * @param gamer2
	 */
	public void afficheVictoire(Joueur gamer1, Joueur gamer2) {
		switch(victoire(gamer1, gamer2)) {
		case 0:
			System.out.println("\nEgalite parfaite des joueurs");
			break;
		case 1:
			System.out.println("\nVictoire du Joueur 1");
			break;
		case 2:
			System.out.println("\nVictoire du Joueur 2");
			break;
		}
	}
	
	/**
	 * Loading file with the developpement cards 
	 * @param path
	 * @param cs
	 * @throws IOException
	 */
	public void load(Path path, Charset cs) throws IOException {
		try (var reader = Files.newBufferedReader(path, cs)) {
			String ligne;
			
			while ((ligne = reader.readLine()) != null) {
				this.adding(CarteDev.fromText(ligne));
			}
		}
	}
	/**
	 * Overload of the load function if there is a different file
	 * @param path
	 * @throws IOException
	 */
	public void load(Path path) throws IOException {
		load(path, Charset.forName("UTF-8"));
	}
}
