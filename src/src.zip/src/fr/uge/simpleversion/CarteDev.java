package fr.uge.simpleversion;

import java.util.Objects;

public record CarteDev(String couleur) {

	/**
	 * CarteDev constructor
	 * Using pre-conditions to verify that the color is the right one
	 * @param couleur
	 */
	public CarteDev(String couleur) {
		Objects.requireNonNull(couleur);
		this.couleur = couleur;
	}
	
	/**
	 * Takes the values and input it in the CarteDev
	 * @param couleur
	 * @return CarteDev
	 */
	public static CarteDev fromText(String couleur) {
		return new CarteDev(couleur);
	}
	
	@Override
	public String toString() {
		return "[" + couleur + "]";
	}
}

