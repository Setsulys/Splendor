package fr.uge.simpleversion;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Partie {
	
	/**
	 * When a player buy a card the number of token used is returned to the board
	 * @param couleur
	 * @param gamer
	 */
	public boolean retourJeton(String couleur, Joueur gamer) {
		int retour = 0;
		if (couleur.equals("vert") && (retour = gamer.nb_carte_vert - gamer.jeton_vert) < 0) {
			Plateau.jeton_vert -= retour;gamer.jeton_vert += retour;return true;
		}
		if (couleur.equals("bleu") && (retour = gamer.nb_carte_bleu - gamer.jeton_bleu) < 0) {
			Plateau.jeton_bleu -= retour;gamer.jeton_bleu += retour;return true;
		} 
		if (couleur.equals("rouge") && (retour = gamer.nb_carte_rouge - gamer.jeton_rouge) < 0) {
			Plateau.jeton_rouge -= retour;gamer.jeton_rouge += retour;return true;
		}
		if (couleur.equals("blanc") && (retour = gamer.nb_carte_blanc - gamer.jeton_blanc) < 0) {
			Plateau.jeton_blanc -= retour;gamer.jeton_blanc += retour;return true;
		}
		if (couleur.equals("noir") && (retour = gamer.nb_carte_noir - gamer.jeton_noir) < 0) {
			Plateau.jeton_noir -= retour;gamer.jeton_noir += retour;return true;
		}
		return false;
	}
	
	
	/**
	 * When the player buy a card we add a prestige to him
	 * @param couleur
	 * @param gamer
	 * @param game
	 * @return boolean
	 */
	public boolean joueurAcheteCarte(String couleur, Joueur gamer, Plateau game) {
		var carte_removed = game.carteAchat(couleur);
		if (gamer.verifJetonJoueur(couleur) && carte_removed != null) {
			gamer.prestige += 1;
			if(carte_removed.couleur().equals("vert") && retourJeton("vert", gamer)) {
				gamer.nb_carte_vert++; game.afficheCarteVisible(); return true;
			}
			if(carte_removed.couleur().equals("bleu") && retourJeton("bleu", gamer)) {
				gamer.nb_carte_bleu++; game.afficheCarteVisible(); return true;
			}
			if(carte_removed.couleur().equals("rouge") && retourJeton("rouge", gamer)) {
				gamer.nb_carte_rouge++; game.afficheCarteVisible(); return true;
			}
			if(carte_removed.couleur().equals("blanc") && retourJeton("blanc", gamer)) {
				gamer.nb_carte_blanc++; game.afficheCarteVisible(); return true;
			}
			if(carte_removed.couleur().equals("noir") && retourJeton("noir", gamer)) {
				gamer.nb_carte_noir++; game.afficheCarteVisible(); return true;
			}
		}
		return false;
	}
	
	
	/**
	 * Check the conditions for a player if he can take 2 tokens of same color
	 * @param couleur
	 * @param gamer
	 * @param game
	 * @return boolean
	 */
	public boolean joueurPiocheJetonSimilaire(String couleur, Joueur gamer, Plateau game) {
		int nb_jeton = 2;
		
		if (game.verifJetonSimilaire(couleur)) {
			while (nb_jeton > 0 && game.verifJeton(couleur)) {
				gamer.ajouteJeton(couleur, gamer);
				nb_jeton--;
			}
			return true;
		}
		return false;
	}
	
	
	/**
	 * Check if there is only one type of token on the board and if the player can take it
	 * @param couleur1
	 * @param gamer
	 * @param game
	 * @return boolean
	 */
	public boolean joueurPiocheJetonDifferentUneCouleur(String couleur1, Joueur gamer, Plateau game) {
		if (game.verifJeton(couleur1)) {
			gamer.ajouteJeton(couleur1, gamer);
			return true;
		}
		return false;
	}
	/**
	 * Check if there is only two type of token on the board and if the player can take it
	 * The player must take two different type of token
	 * @param couleur1
	 * @param couleur2
	 * @param gamer
	 * @param game
	 * @return boolean
	 */
	public boolean joueurPiocheJetonDifferentDeuxCouleurs(String couleur1, String couleur2, Joueur gamer, Plateau game) {
		if ((!couleur1.equals(couleur2) && !couleur1.equals(couleur2))) {
			if (game.verifJeton(couleur1) && game.verifJeton(couleur2)) {
				gamer.ajouteJeton(couleur1, gamer);
				gamer.ajouteJeton(couleur2, gamer);
				return true;
			}
		}
		return false;
	}
	

	/**
	 * Check if there is three type of token on the board and if the player can take it
	 * the player must take thre different type of token
	 * @param couleur1
	 * @param couleur2
	 * @param couleur3
	 * @param gamer
	 * @param game
	 * @return boolean
	 */
	public boolean joueurPiocheJetonDifferent(String couleur1, String couleur2, String couleur3, Joueur gamer, Plateau game) {
		if ((!couleur1.equals(couleur2) && !couleur1.equals(couleur3) && !couleur2.equals(couleur3))) {
			if (game.verifJeton(couleur1) && game.verifJeton(couleur2) && game.verifJeton(couleur3)) {
				gamer.ajouteJeton(couleur1, gamer);
				gamer.ajouteJeton(couleur2, gamer);
				gamer.ajouteJeton(couleur3, gamer);
				return true;
			}	
			return false;
		}
		return false;
	}
	
	/**
	 * Check how many type of token there is on the board
	 * @param gamer
	 * @param game
	 * @return boolean
	 * @throws IOException
	 */
	public boolean joueurPiocheJeton(Joueur gamer,Plateau game) throws IOException {
		if(Plateau.resteJeton() >= 3) {
			return joueurPiocheJetonDifferent(stream(),stream(),stream(),gamer,game);
		}
		if(Plateau.resteJeton() == 2) {
			return joueurPiocheJetonDifferentDeuxCouleurs(stream(),stream(), gamer, game);
		}
		if(Plateau.resteJeton() == 1 ) {	
			return joueurPiocheJetonDifferentUneCouleur(stream(), gamer, game); 
		}
		return false;
	}
	
	/**
	 * Check what action the player wants to do and if there is a good value inputed in the stream
	 * @return int
	 * @throws IOException
	 */
	public int verifAction() throws IOException {
		var line = new BufferedReader(new InputStreamReader(System.in));
		int action = 0;
		
		System.out.println("\n\nChoisissez une action :\n1 - Pioche de jeton similaire \n2 - Pioche de jeton different\n3 - Selection de carte \n");
		
		while(action != 1 && action != 2 && action != 3) {
			try {
				System.out.print(">> ");
				action = Integer.parseInt(line.readLine());
			} catch(NumberFormatException nfe) {
				System.err.println("Invalid Format");
			}
		}
		return action;
	}
	
	/**
	 * This method execute the action selected and if it cannot be done 
	 * the player must reselect another action
	 * @param gamer
	 * @param game
	 * @throws IOException
	 */
	public void choixAction(Joueur gamer, Plateau game) throws IOException {
		switch(verifAction()) {
		case 1: 
			if (!(joueurPiocheJetonSimilaire(stream(), gamer, game))) {  /* Prendre 2 jetons pierre precieuse de la meme couleur. (token == 4) */
				choixAction(gamer, game);
			} break;
		case 2: 
			if (!joueurPiocheJeton(gamer,game)) {/* Prendre 3 jetons pierre precieuse de couleur differente. */ 
				choixAction(gamer, game);
			} break; 
		case 3: 
			if (!(joueurAcheteCarte(stream(), gamer, game))) { /* Acheter 1 carte developpement face visible au centre de la table */
				choixAction(gamer, game);
			} break;
		}
		return;
	}
	
	
	/**
	 * Selection of the color of the token or the card
	 * @return String
	 * @throws IOException
	 */
    public String stream() throws IOException { 
        var br = new BufferedReader(new InputStreamReader(System.in));
        String couleur = "";
        
        while (!couleur.equals("vert") && !couleur.equals("bleu") && !couleur.equals("rouge") && !couleur.equals("blanc") && !couleur.equals("noir")) {
        	try {
        		System.out.print("Choisisez une couleur >> ");
        		couleur = br.readLine();
        	} catch (NumberFormatException nfe) {
				System.err.println("Invalid Format");
        	}
        }
        return couleur;
    }
    
    /**
     * Select a player who will play
     * @param gamer
     * @param game
     * @throws IOException
     */
    public void tourJoueur(Joueur gamer, Plateau game) throws IOException {
    	System.out.println("Cartes faces visibles : \n" + game.carte_visible + "\n");
		System.out.println("Jeton disponible : ");
		game.afficherJetonPlateau();
		System.out.println("\n---------------- Joueur " + gamer.nbJoueur +  ": ----------------\n");
		System.out.println(gamer);
		choixAction(gamer, game);
    }
	/**
	 * Game launch
	 * @param player1
	 * @param player2
	 * @param game
	 * @throws IOException
	 */
    public void partieDeJeu(Joueur player1, Joueur player2, Plateau game) throws IOException {
    	var tour = 1;
    	
    	game.afficheCarteVisible();
		
		while(player1.prestige < 15 && player2.prestige < 15) {
			System.out.println("\n~~~~~~~~~~~~~~~~ Tour : " + tour + " ~~~~~~~~~~~~~~~~\n");
			tourJoueur(player1,game);
			System.out.println("\n======== Autour du joueur suivant ========\n");
			tourJoueur(player2,game);
			tour++;
		}
		game.afficheVictoire(player1, player2);
    }
}
