package fr.uge.simpleversion;


public class Joueur {
	public int nbJoueur;
	public int jeton_vert;
	public int jeton_bleu;
	public int jeton_rouge;
	public int jeton_blanc;
	public int jeton_noir;
	public int nb_carte_vert;
	public int nb_carte_bleu;
	public int nb_carte_rouge;
	public int nb_carte_blanc;
	public int nb_carte_noir;
	public int prestige;
	
	/**
	 * Joueur Constructor
	 * 
	 * @param jeton_vert
	 * @param jeton_bleu
	 * @param jeton_rouge
	 * @param jeton_blanc
	 * @param jeton_noir
	 * @param nb_carte_vert
	 * @param nb_carte_bleu
	 * @param nb_carte_rouge
	 * @param nb_carte_blanc
	 * @param nb_carte_noir
	 * @param prestige
	 */
	public Joueur(int nbJoueur,int jeton_vert, int jeton_bleu, int jeton_rouge, int jeton_blanc, int jeton_noir, int nb_carte_vert, int nb_carte_bleu, int nb_carte_rouge, int nb_carte_blanc, int nb_carte_noir, int prestige) {
		if((jeton_vert < 0 || jeton_vert > 4) || (jeton_bleu < 0 || jeton_bleu > 4) || (jeton_rouge < 0 || jeton_rouge > 4) || (jeton_blanc < 0 || jeton_blanc > 4) || (jeton_noir < 0 || jeton_noir > 4)) {
			throw new IllegalStateException("Nombre de jeton invalide");
		}
		if(nb_carte_vert < 0 || nb_carte_bleu < 0 || nb_carte_rouge < 0 || nb_carte_blanc < 0 || nb_carte_noir < 0) {
			throw new IllegalStateException("Nombre de carte < 0");
		}
		if(prestige < 0) {
			throw new IllegalStateException("prestige < 0");
		}
		this.nbJoueur = nbJoueur;
		this.jeton_vert = jeton_vert;
		this.jeton_bleu = jeton_bleu;
		this.jeton_rouge = jeton_rouge;
		this.jeton_blanc = jeton_blanc;
		this.jeton_noir = jeton_noir;
		
		this.nb_carte_vert = nb_carte_vert;
		this.nb_carte_bleu = nb_carte_bleu;
		this.nb_carte_rouge = nb_carte_rouge;
		this.nb_carte_blanc = nb_carte_blanc;
		this.nb_carte_noir = nb_carte_noir;
		this.prestige = prestige;
	}
	
	
	/**
	 * If the player have cards and token of the same color and there is at least 3 the method return true
	 * @param couleur
	 * @return boolean
	 */
	public boolean verifJetonJoueur(String couleur) {
		if(couleur.equals("vert") && (jeton_vert + nb_carte_vert < 3)) {
			return false;
		}
		if(couleur.equals("vert") && (jeton_bleu + nb_carte_bleu < 3)) {
			return false;
		}
		if(couleur.equals("vert") && (jeton_rouge + nb_carte_rouge < 3)){
			return false;
		}
		if(couleur.equals("vert") && (jeton_blanc + nb_carte_blanc < 3)) {
			return false;
		}
		if(couleur.equals("vert") && (jeton_noir + nb_carte_noir < 3)) {
			return false;
		}
		return true;
	}

	/**
	 * Add tokens to the player depending of the color asked and withdraw it from the board
	 * @param couleur
	 * @param gamer
	 */
	public void ajouteJeton(String couleur, Joueur gamer) {
		switch(couleur) {
		case "vert":
			gamer.jeton_vert++; Plateau.jeton_vert--; break;
		case "bleu":
			gamer.jeton_bleu++; Plateau.jeton_bleu--; break;
		case "rouge":
			gamer.jeton_rouge++; Plateau.jeton_rouge--; break;
		case "blanc":
			gamer.jeton_blanc++; Plateau.jeton_blanc--; break;
		case "noir":
			gamer.jeton_noir++; Plateau.jeton_noir--; break;
		}
	}
	
	@Override
	public String toString() {
		return "Prestige\t: " + prestige + 
				" \nJeton Vert\t: " + jeton_vert + "  |  Carte verte\t: " + nb_carte_vert +
				" \nJeton Blanc\t: " + jeton_blanc + "  |  Carte blanc\t: " + nb_carte_blanc +
				" \nJeton Bleu\t: " + jeton_bleu + "  |  Carte bleu\t: " + nb_carte_bleu +
				" \nJeton Noir\t: " + jeton_noir + "  |  Carte noir\t: " + nb_carte_noir +
				" \nJeton rouge\t: " + jeton_rouge + "  |  Carte rouge\t: " + nb_carte_rouge;
	}
}
