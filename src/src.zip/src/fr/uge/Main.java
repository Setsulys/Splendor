package fr.uge;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import fr.uge.simpleversion.main.*;
import fr.uge.splendor.Graphique;
import fr.uge.splendor.Graphique.*;
import fr.uge.splendor.main.*;

public class Main{
	/**
	 * This Method return the value entered in the stream
	 * @return int
	 * @throws IOException
	 */
	public static int typeJeu() throws IOException {
		var line = new BufferedReader(new InputStreamReader(System.in));
		int action = 0;
		
		System.out.println("Choisisez le type du jeu \n 1 - Version Simple\n 2 - Version Complete\n");
		
		while(action != 2 && action != 1 ) {
			try {
				System.out.print(">> ");
				action = Integer.parseInt(line.readLine());
			} catch(NumberFormatException nfe) {
				System.err.println("Invalid Format");
			}
		}
		return action;
	}
	
	
	public static int typeGraphique() throws IOException {
		var line = new BufferedReader(new InputStreamReader(System.in));
		int action = 0;
		
		System.out.println("Choisisez le type du jeu \n 1 - Version Terminal\n 2 - Version Graphique(NON FINI)\n");
		
		while(action != 2 && action != 1 ) {
			try {
				System.out.print(">> ");
				action = Integer.parseInt(line.readLine());
			} catch(NumberFormatException nfe) {
				System.err.println("Invalid Format");
			}
		}
		return action;
	}
	/**
	 * Main method
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {
		if(typeJeu()==2) {
			if(typeGraphique()==1) {
				Splendor.splendor();
			}
			else {
				Graphique.graphics();
			}
		}
		else {
			SplendorSimple.splendorSimple();
		}
	}
}